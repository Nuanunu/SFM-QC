﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vmtcreaterH
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vmtcreaterH))
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.baseP = New System.Windows.Forms.Panel()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.t1 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.t3 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.baseB = New System.Windows.Forms.Button()
        Me.t2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.detailP = New System.Windows.Forms.Panel()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.t4 = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.detailB = New System.Windows.Forms.Button()
        Me.highP = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.highB = New System.Windows.Forms.Button()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.t6 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.envirP = New System.Windows.Forms.Panel()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.envirB = New System.Windows.Forms.Button()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.t7 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.t8 = New System.Windows.Forms.TextBox()
        Me.illuP = New System.Windows.Forms.Panel()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.t9 = New System.Windows.Forms.TextBox()
        Me.t10 = New System.Windows.Forms.TextBox()
        Me.illuB = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.otherP = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.t11 = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.otherB = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.creat = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.vmtnameTB = New System.Windows.Forms.TextBox()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.baseP.SuspendLayout()
        Me.detailP.SuspendLayout()
        Me.highP.SuspendLayout()
        Me.envirP.SuspendLayout()
        Me.illuP.SuspendLayout()
        Me.otherP.SuspendLayout()
        Me.SuspendLayout()
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FlowLayoutPanel1.Controls.Add(Me.baseP)
        Me.FlowLayoutPanel1.Controls.Add(Me.detailP)
        Me.FlowLayoutPanel1.Controls.Add(Me.highP)
        Me.FlowLayoutPanel1.Controls.Add(Me.envirP)
        Me.FlowLayoutPanel1.Controls.Add(Me.illuP)
        Me.FlowLayoutPanel1.Controls.Add(Me.otherP)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(12, 12)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(512, 564)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'baseP
        '
        Me.baseP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.baseP.Controls.Add(Me.CheckBox1)
        Me.baseP.Controls.Add(Me.Label8)
        Me.baseP.Controls.Add(Me.CheckBox4)
        Me.baseP.Controls.Add(Me.t1)
        Me.baseP.Controls.Add(Me.Label12)
        Me.baseP.Controls.Add(Me.t3)
        Me.baseP.Controls.Add(Me.Label1)
        Me.baseP.Controls.Add(Me.Label11)
        Me.baseP.Controls.Add(Me.baseB)
        Me.baseP.Controls.Add(Me.t2)
        Me.baseP.Controls.Add(Me.Label6)
        Me.baseP.Location = New System.Drawing.Point(3, 3)
        Me.baseP.Name = "baseP"
        Me.baseP.Size = New System.Drawing.Size(483, 196)
        Me.baseP.TabIndex = 1
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(182, 48)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox1.TabIndex = 47
        Me.CheckBox1.Text = "开启"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 50)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(157, 15)
        Me.Label8.TabIndex = 46
        Me.Label8.Text = "基础贴图使用透明通道"
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(92, 159)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox4.TabIndex = 8
        Me.CheckBox4.Text = "开启"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        't1
        '
        Me.t1.AllowDrop = True
        Me.t1.Location = New System.Drawing.Point(76, 13)
        Me.t1.Name = "t1"
        Me.t1.Size = New System.Drawing.Size(396, 25)
        Me.t1.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(4, 160)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 15)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "无视正反面"
        '
        't3
        '
        Me.t3.AllowDrop = True
        Me.t3.Location = New System.Drawing.Point(77, 123)
        Me.t3.Name = "t3"
        Me.t3.Size = New System.Drawing.Size(395, 25)
        Me.t3.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "基础贴图"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(4, 126)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 15)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "翘曲贴图"
        '
        'baseB
        '
        Me.baseB.Location = New System.Drawing.Point(391, 42)
        Me.baseB.Name = "baseB"
        Me.baseB.Size = New System.Drawing.Size(87, 31)
        Me.baseB.TabIndex = 0
        Me.baseB.Tag = "0"
        Me.baseB.Text = "展开"
        Me.baseB.UseVisualStyleBackColor = True
        '
        't2
        '
        Me.t2.AllowDrop = True
        Me.t2.Location = New System.Drawing.Point(77, 88)
        Me.t2.Name = "t2"
        Me.t2.Size = New System.Drawing.Size(395, 25)
        Me.t2.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 91)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 15)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "法线贴图"
        '
        'detailP
        '
        Me.detailP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.detailP.Controls.Add(Me.CheckBox11)
        Me.detailP.Controls.Add(Me.Label39)
        Me.detailP.Controls.Add(Me.CheckBox8)
        Me.detailP.Controls.Add(Me.Label9)
        Me.detailP.Controls.Add(Me.t4)
        Me.detailP.Controls.Add(Me.Label46)
        Me.detailP.Controls.Add(Me.TextBox23)
        Me.detailP.Controls.Add(Me.Label47)
        Me.detailP.Controls.Add(Me.Label48)
        Me.detailP.Controls.Add(Me.detailB)
        Me.detailP.Location = New System.Drawing.Point(3, 205)
        Me.detailP.Name = "detailP"
        Me.detailP.Size = New System.Drawing.Size(482, 143)
        Me.detailP.TabIndex = 6
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(113, 112)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox11.TabIndex = 40
        Me.CheckBox11.Text = "开启"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(10, 113)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(97, 15)
        Me.Label39.TabIndex = 39
        Me.Label39.Text = "开启伪自发光"
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(134, 83)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox8.TabIndex = 38
        Me.CheckBox8.Text = "开启"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 84)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 15)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "对准UV 默认平铺"
        '
        't4
        '
        Me.t4.AllowDrop = True
        Me.t4.Location = New System.Drawing.Point(75, 8)
        Me.t4.Name = "t4"
        Me.t4.Size = New System.Drawing.Size(309, 25)
        Me.t4.TabIndex = 35
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(213, 48)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(84, 15)
        Me.Label46.TabIndex = 31
        Me.Label46.Text = "百分比 0-1"
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(76, 45)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(131, 25)
        Me.TextBox23.TabIndex = 30
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(6, 48)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(67, 15)
        Me.Label47.TabIndex = 29
        Me.Label47.Text = "可见程度"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(3, 11)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(67, 15)
        Me.Label48.TabIndex = 5
        Me.Label48.Text = "细节贴图"
        '
        'detailB
        '
        Me.detailB.Location = New System.Drawing.Point(390, 3)
        Me.detailB.Name = "detailB"
        Me.detailB.Size = New System.Drawing.Size(87, 31)
        Me.detailB.TabIndex = 1
        Me.detailB.Tag = "0"
        Me.detailB.Text = "展开"
        Me.detailB.UseVisualStyleBackColor = True
        '
        'highP
        '
        Me.highP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.highP.Controls.Add(Me.Label21)
        Me.highP.Controls.Add(Me.CheckBox2)
        Me.highP.Controls.Add(Me.Label20)
        Me.highP.Controls.Add(Me.Label19)
        Me.highP.Controls.Add(Me.Label2)
        Me.highP.Controls.Add(Me.TextBox7)
        Me.highP.Controls.Add(Me.highB)
        Me.highP.Controls.Add(Me.TextBox6)
        Me.highP.Controls.Add(Me.Label13)
        Me.highP.Controls.Add(Me.TextBox5)
        Me.highP.Controls.Add(Me.Label14)
        Me.highP.Controls.Add(Me.t6)
        Me.highP.Controls.Add(Me.Label15)
        Me.highP.Controls.Add(Me.CheckBox6)
        Me.highP.Controls.Add(Me.Label16)
        Me.highP.Controls.Add(Me.CheckBox5)
        Me.highP.Controls.Add(Me.Label17)
        Me.highP.Controls.Add(Me.Label18)
        Me.highP.Location = New System.Drawing.Point(3, 354)
        Me.highP.Name = "highP"
        Me.highP.Size = New System.Drawing.Size(483, 241)
        Me.highP.TabIndex = 8
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(228, 117)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(235, 15)
        Me.Label21.TabIndex = 20
        Me.Label21.Text = "[Φx Φy Φz] 例:[0.05 0.5 1]"
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(76, 10)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox2.TabIndex = 5
        Me.CheckBox2.Text = "开启"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(193, 83)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(137, 15)
        Me.Label20.TabIndex = 19
        Me.Label20.Text = "0-1百分比 可超过1"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(193, 53)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(154, 15)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "1-100整数 可超过100"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 11)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "高光"
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(91, 114)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(131, 25)
        Me.TextBox7.TabIndex = 17
        '
        'highB
        '
        Me.highB.Location = New System.Drawing.Point(391, 3)
        Me.highB.Name = "highB"
        Me.highB.Size = New System.Drawing.Size(87, 31)
        Me.highB.TabIndex = 1
        Me.highB.Tag = "0"
        Me.highB.Text = "展开"
        Me.highB.UseVisualStyleBackColor = True
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(75, 80)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(101, 25)
        Me.TextBox6.TabIndex = 16
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(4, 53)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(37, 15)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "亮度"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(75, 50)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(101, 25)
        Me.TextBox5.TabIndex = 15
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(4, 83)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 15)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "硬度"
        '
        't6
        '
        Me.t6.AllowDrop = True
        Me.t6.Location = New System.Drawing.Point(75, 145)
        Me.t6.Name = "t6"
        Me.t6.Size = New System.Drawing.Size(395, 25)
        Me.t6.TabIndex = 14
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(4, 117)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(82, 15)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "菲涅尔距离"
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(267, 181)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox6.TabIndex = 13
        Me.CheckBox6.Text = "开启"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(4, 148)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(67, 15)
        Me.Label16.TabIndex = 9
        Me.Label16.Text = "高光贴图"
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(267, 211)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox5.TabIndex = 12
        Me.CheckBox5.Text = "开启"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 182)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(257, 15)
        Me.Label17.TabIndex = 10
        Me.Label17.Text = "使用基础贴图alpha通道作为高光贴图"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(4, 212)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(202, 15)
        Me.Label18.TabIndex = 11
        Me.Label18.Text = "高光贴图的颜色附给基础贴图"
        '
        'envirP
        '
        Me.envirP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.envirP.Controls.Add(Me.Label29)
        Me.envirP.Controls.Add(Me.Label23)
        Me.envirP.Controls.Add(Me.TextBox12)
        Me.envirP.Controls.Add(Me.CheckBox3)
        Me.envirP.Controls.Add(Me.Label30)
        Me.envirP.Controls.Add(Me.Label27)
        Me.envirP.Controls.Add(Me.Label3)
        Me.envirP.Controls.Add(Me.TextBox11)
        Me.envirP.Controls.Add(Me.envirB)
        Me.envirP.Controls.Add(Me.Label28)
        Me.envirP.Controls.Add(Me.Label22)
        Me.envirP.Controls.Add(Me.Label25)
        Me.envirP.Controls.Add(Me.t7)
        Me.envirP.Controls.Add(Me.TextBox10)
        Me.envirP.Controls.Add(Me.Label24)
        Me.envirP.Controls.Add(Me.Label26)
        Me.envirP.Controls.Add(Me.t8)
        Me.envirP.Location = New System.Drawing.Point(3, 601)
        Me.envirP.Name = "envirP"
        Me.envirP.Size = New System.Drawing.Size(483, 212)
        Me.envirP.TabIndex = 7
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(249, 180)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(196, 15)
        Me.Label29.TabIndex = 28
        Me.Label29.Text = "RGB数组 例:[255 255 255]"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(198, 11)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(155, 15)
        Me.Label23.TabIndex = 6
        Me.Label23.Text = "默认使用env_cubemap"
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(112, 177)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(131, 25)
        Me.TextBox12.TabIndex = 27
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(80, 10)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox3.TabIndex = 5
        Me.CheckBox3.Text = "开启"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(9, 180)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(97, 15)
        Me.Label30.TabIndex = 26
        Me.Label30.Text = "环境反射颜色"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(198, 145)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(137, 15)
        Me.Label27.TabIndex = 25
        Me.Label27.Text = "0-1百分比 可超过1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 11)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(67, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "环境反射"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(80, 142)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(101, 25)
        Me.TextBox11.TabIndex = 24
        '
        'envirB
        '
        Me.envirB.Location = New System.Drawing.Point(391, 3)
        Me.envirB.Name = "envirB"
        Me.envirB.Size = New System.Drawing.Size(87, 31)
        Me.envirB.TabIndex = 1
        Me.envirB.Tag = "0"
        Me.envirB.Text = "展开"
        Me.envirB.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(9, 145)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(52, 15)
        Me.Label28.TabIndex = 23
        Me.Label28.Text = "饱和度"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(7, 49)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(67, 15)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "环境贴图"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(198, 114)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(137, 15)
        Me.Label25.TabIndex = 22
        Me.Label25.Text = "0-1百分比 可超过1"
        '
        't7
        '
        Me.t7.AllowDrop = True
        Me.t7.Location = New System.Drawing.Point(80, 46)
        Me.t7.Name = "t7"
        Me.t7.Size = New System.Drawing.Size(395, 25)
        Me.t7.TabIndex = 15
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(80, 111)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(101, 25)
        Me.TextBox10.TabIndex = 21
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(7, 83)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(67, 15)
        Me.Label24.TabIndex = 16
        Me.Label24.Text = "遮罩贴图"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(9, 114)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(52, 15)
        Me.Label26.TabIndex = 20
        Me.Label26.Text = "对比度"
        '
        't8
        '
        Me.t8.AllowDrop = True
        Me.t8.Location = New System.Drawing.Point(80, 80)
        Me.t8.Name = "t8"
        Me.t8.Size = New System.Drawing.Size(395, 25)
        Me.t8.TabIndex = 17
        '
        'illuP
        '
        Me.illuP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.illuP.Controls.Add(Me.CheckBox7)
        Me.illuP.Controls.Add(Me.t9)
        Me.illuP.Controls.Add(Me.t10)
        Me.illuP.Controls.Add(Me.illuB)
        Me.illuP.Controls.Add(Me.Label34)
        Me.illuP.Controls.Add(Me.Label10)
        Me.illuP.Controls.Add(Me.Label33)
        Me.illuP.Controls.Add(Me.Label32)
        Me.illuP.Controls.Add(Me.Label31)
        Me.illuP.Controls.Add(Me.TextBox13)
        Me.illuP.Location = New System.Drawing.Point(3, 819)
        Me.illuP.Name = "illuP"
        Me.illuP.Size = New System.Drawing.Size(483, 144)
        Me.illuP.TabIndex = 9
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(77, 13)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox7.TabIndex = 36
        Me.CheckBox7.Text = "开启"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        't9
        '
        Me.t9.AllowDrop = True
        Me.t9.Location = New System.Drawing.Point(109, 77)
        Me.t9.Name = "t9"
        Me.t9.Size = New System.Drawing.Size(361, 25)
        Me.t9.TabIndex = 35
        '
        't10
        '
        Me.t10.AllowDrop = True
        Me.t10.Location = New System.Drawing.Point(109, 108)
        Me.t10.Name = "t10"
        Me.t10.Size = New System.Drawing.Size(361, 25)
        Me.t10.TabIndex = 34
        '
        'illuB
        '
        Me.illuB.Location = New System.Drawing.Point(391, 3)
        Me.illuB.Name = "illuB"
        Me.illuB.Size = New System.Drawing.Size(87, 31)
        Me.illuB.TabIndex = 1
        Me.illuB.Tag = "0"
        Me.illuB.Text = "展开"
        Me.illuB.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(6, 111)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(97, 15)
        Me.Label34.TabIndex = 33
        Me.Label34.Text = "着色颜色贴图"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 14)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 15)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "强制着色"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(6, 80)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(97, 15)
        Me.Label33.TabIndex = 32
        Me.Label33.Text = "着色遮罩贴图"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(6, 46)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(97, 15)
        Me.Label32.TabIndex = 29
        Me.Label32.Text = "强制着色颜色"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(246, 46)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(196, 15)
        Me.Label31.TabIndex = 31
        Me.Label31.Text = "RGB数组 例:[255 255 255]"
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(109, 43)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(131, 25)
        Me.TextBox13.TabIndex = 30
        '
        'otherP
        '
        Me.otherP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.otherP.Controls.Add(Me.Label4)
        Me.otherP.Controls.Add(Me.t11)
        Me.otherP.Controls.Add(Me.Label38)
        Me.otherP.Controls.Add(Me.CheckBox10)
        Me.otherP.Controls.Add(Me.Label37)
        Me.otherP.Controls.Add(Me.CheckBox9)
        Me.otherP.Controls.Add(Me.Label35)
        Me.otherP.Controls.Add(Me.TextBox16)
        Me.otherP.Controls.Add(Me.Label36)
        Me.otherP.Controls.Add(Me.otherB)
        Me.otherP.Controls.Add(Me.Label5)
        Me.otherP.Location = New System.Drawing.Point(3, 969)
        Me.otherP.Name = "otherP"
        Me.otherP.Size = New System.Drawing.Size(483, 217)
        Me.otherP.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(212, 113)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 15)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "默认为使用"
        '
        't11
        '
        Me.t11.AllowDrop = True
        Me.t11.Location = New System.Drawing.Point(111, 143)
        Me.t11.Name = "t11"
        Me.t11.Size = New System.Drawing.Size(361, 25)
        Me.t11.TabIndex = 42
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(7, 146)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(99, 15)
        Me.Label38.TabIndex = 41
        Me.Label38.Text = "指定ssao贴图"
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(97, 113)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox10.TabIndex = 40
        Me.CheckBox10.Text = "关闭"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(7, 114)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(84, 15)
        Me.Label37.TabIndex = 39
        Me.Label37.Text = "不使用ssao"
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(133, 47)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(59, 19)
        Me.CheckBox9.TabIndex = 38
        Me.CheckBox9.Text = "开启"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(154, 69)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(312, 15)
        Me.Label35.TabIndex = 37
        Me.Label35.Text = "RGB数组 例:[255 255 255] /浮点数 例:1.0"
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(10, 66)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(131, 25)
        Me.TextBox16.TabIndex = 36
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(7, 48)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(120, 15)
        Me.Label36.TabIndex = 35
        Me.Label36.Text = "漫反射颜色/亮度"
        '
        'otherB
        '
        Me.otherB.Location = New System.Drawing.Point(391, 3)
        Me.otherB.Name = "otherB"
        Me.otherB.Size = New System.Drawing.Size(87, 31)
        Me.otherB.TabIndex = 1
        Me.otherB.Tag = "0"
        Me.otherB.Text = "展开"
        Me.otherB.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 11)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 15)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "其他单项"
        '
        'creat
        '
        Me.creat.Location = New System.Drawing.Point(347, 583)
        Me.creat.Name = "creat"
        Me.creat.Size = New System.Drawing.Size(177, 48)
        Me.creat.TabIndex = 1
        Me.creat.Text = "保存"
        Me.creat.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(21, 598)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 15)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "vmt名称"
        '
        'vmtnameTB
        '
        Me.vmtnameTB.Location = New System.Drawing.Point(94, 597)
        Me.vmtnameTB.Name = "vmtnameTB"
        Me.vmtnameTB.Size = New System.Drawing.Size(234, 25)
        Me.vmtnameTB.TabIndex = 3
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.DefaultExt = "vmt"
        Me.SaveFileDialog1.Filter = "vmt文件|*.vmt|所有文件|*.*"
        Me.SaveFileDialog1.Title = "生成vmt"
        '
        'vmtcreaterH
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 643)
        Me.Controls.Add(Me.vmtnameTB)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.creat)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "vmtcreaterH"
        Me.Text = "高级vmt制作器"
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.baseP.ResumeLayout(False)
        Me.baseP.PerformLayout()
        Me.detailP.ResumeLayout(False)
        Me.detailP.PerformLayout()
        Me.highP.ResumeLayout(False)
        Me.highP.PerformLayout()
        Me.envirP.ResumeLayout(False)
        Me.envirP.PerformLayout()
        Me.illuP.ResumeLayout(False)
        Me.illuP.PerformLayout()
        Me.otherP.ResumeLayout(False)
        Me.otherP.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents baseP As Panel
    Friend WithEvents baseB As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents t1 As TextBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents Label12 As Label
    Friend WithEvents t3 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents t2 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents detailP As Panel
    Friend WithEvents t4 As TextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents detailB As Button
    Friend WithEvents highP As Panel
    Friend WithEvents Label21 As Label
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents highB As Button
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents t6 As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents Label16 As Label
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents envirP As Panel
    Friend WithEvents Label29 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents Label30 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents envirB As Button
    Friend WithEvents Label28 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents t7 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents t8 As TextBox
    Friend WithEvents illuP As Panel
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents t9 As TextBox
    Friend WithEvents t10 As TextBox
    Friend WithEvents illuB As Button
    Friend WithEvents Label34 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents otherP As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents t11 As TextBox
    Friend WithEvents Label38 As Label
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents Label37 As Label
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents Label35 As Label
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents Label36 As Label
    Friend WithEvents otherB As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents creat As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents vmtnameTB As TextBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Label8 As Label
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents Label9 As Label
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents Label39 As Label
End Class
