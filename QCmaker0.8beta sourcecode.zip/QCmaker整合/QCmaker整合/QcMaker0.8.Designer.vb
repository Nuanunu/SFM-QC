﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.B_preview_s = New System.Windows.Forms.Button()
        Me.B_outpath_s = New System.Windows.Forms.Button()
        Me.B_smdpath_s = New System.Windows.Forms.Button()
        Me.L_preview_s = New System.Windows.Forms.Label()
        Me.T_preview_s = New System.Windows.Forms.TextBox()
        Me.T_outpath_s = New System.Windows.Forms.TextBox()
        Me.T_smdpath_s = New System.Windows.Forms.TextBox()
        Me.L_outpath_s = New System.Windows.Forms.Label()
        Me.L_smdpath_s = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.T2_cd_z = New System.Windows.Forms.TextBox()
        Me.T_cd_z = New System.Windows.Forms.TextBox()
        Me.L_cd_z = New System.Windows.Forms.Label()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.B4_mdn_z = New System.Windows.Forms.Button()
        Me.B1_mdn_z = New System.Windows.Forms.Button()
        Me.B2_mdn_z = New System.Windows.Forms.Button()
        Me.B3_mdn_z = New System.Windows.Forms.Button()
        Me.T2_mdn_z = New System.Windows.Forms.TextBox()
        Me.T_mdn_z = New System.Windows.Forms.TextBox()
        Me.L_mdn_z = New System.Windows.Forms.Label()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.T2_mdl_z = New System.Windows.Forms.TextBox()
        Me.T_mdl_z = New System.Windows.Forms.TextBox()
        Me.L_mdl_z = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.L2_bdg_z = New System.Windows.Forms.Label()
        Me.Name_bdg_z = New System.Windows.Forms.TextBox()
        Me.L_bdg_z = New System.Windows.Forms.Label()
        Me.List_bdg_z = New System.Windows.Forms.TextBox()
        Me.B_bdg_z = New System.Windows.Forms.Button()
        Me.T_bdg_z = New System.Windows.Forms.TextBox()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.L2_jb_z = New System.Windows.Forms.Label()
        Me.B3_jb_z = New System.Windows.Forms.Button()
        Me.B_jb_z2 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.C1_jb_z = New System.Windows.Forms.CheckBox()
        Me.T_forward_friction = New System.Windows.Forms.TextBox()
        Me.T_forward_constraint = New System.Windows.Forms.TextBox()
        Me.T_up_friction = New System.Windows.Forms.TextBox()
        Me.T_up_constraint = New System.Windows.Forms.TextBox()
        Me.T_left_friction = New System.Windows.Forms.TextBox()
        Me.T_left_constraint = New System.Windows.Forms.TextBox()
        Me.T_damping = New System.Windows.Forms.TextBox()
        Me.T_stiffness = New System.Windows.Forms.TextBox()
        Me.T_base_mass = New System.Windows.Forms.TextBox()
        Me.L_forward_friction = New System.Windows.Forms.Label()
        Me.L_forward_constraint = New System.Windows.Forms.Label()
        Me.L_up_friction = New System.Windows.Forms.Label()
        Me.L_up_constraint = New System.Windows.Forms.Label()
        Me.L_left_friction = New System.Windows.Forms.Label()
        Me.L_left_constraint = New System.Windows.Forms.Label()
        Me.L_damping = New System.Windows.Forms.Label()
        Me.L_stiffness = New System.Windows.Forms.Label()
        Me.L_base_mass = New System.Windows.Forms.Label()
        Me.T_jbn_z = New System.Windows.Forms.TextBox()
        Me.L_jb_z = New System.Windows.Forms.Label()
        Me.Gr_jb_z = New System.Windows.Forms.GroupBox()
        Me.C2_jb_z = New System.Windows.Forms.CheckBox()
        Me.T_angle_constraint = New System.Windows.Forms.TextBox()
        Me.T_along_damping = New System.Windows.Forms.TextBox()
        Me.T_along_stiffness = New System.Windows.Forms.TextBox()
        Me.T_yaw_damping = New System.Windows.Forms.TextBox()
        Me.T_yaw_stiffness = New System.Windows.Forms.TextBox()
        Me.T_pitch_damping = New System.Windows.Forms.TextBox()
        Me.T_pitch_stiffness = New System.Windows.Forms.TextBox()
        Me.T_tip_mass = New System.Windows.Forms.TextBox()
        Me.T_length = New System.Windows.Forms.TextBox()
        Me.L_angle_constraint = New System.Windows.Forms.Label()
        Me.L_along_damping = New System.Windows.Forms.Label()
        Me.L_along_stiffness = New System.Windows.Forms.Label()
        Me.L_yaw_damping = New System.Windows.Forms.Label()
        Me.L_yaw_stiffness = New System.Windows.Forms.Label()
        Me.L_pitch_damping = New System.Windows.Forms.Label()
        Me.L_pitch_stiffness = New System.Windows.Forms.Label()
        Me.L_tip_mass = New System.Windows.Forms.Label()
        Me.L_length = New System.Windows.Forms.Label()
        Me.B1_jb_z = New System.Windows.Forms.Button()
        Me.T_jb_z = New System.Windows.Forms.TextBox()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.T_mem_z = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.T_Mem = New System.Windows.Forms.TextBox()
        Me.L_Mem = New System.Windows.Forms.Label()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.L_items_z = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.T1_item_z = New System.Windows.Forms.TextBox()
        Me.L1_item_z = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.B4_cdm_z = New System.Windows.Forms.Button()
        Me.B3_cdm_z = New System.Windows.Forms.Button()
        Me.B2_cdm_z = New System.Windows.Forms.Button()
        Me.T1_cdm_z = New System.Windows.Forms.TextBox()
        Me.L1_cdm = New System.Windows.Forms.Label()
        Me.B1_cdm_z = New System.Windows.Forms.Button()
        Me.T2_cdm_z = New System.Windows.Forms.TextBox()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.B1_ttg_z = New System.Windows.Forms.Button()
        Me.T1_ttg_z = New System.Windows.Forms.TextBox()
        Me.L1_ttg_z = New System.Windows.Forms.Label()
        Me.B2_ttg_z = New System.Windows.Forms.Button()
        Me.T2_ttg_z = New System.Windows.Forms.TextBox()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.L2_seq_z = New System.Windows.Forms.Label()
        Me.T_seqn = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.T_activity1 = New System.Windows.Forms.TextBox()
        Me.B2_seq_z = New System.Windows.Forms.Button()
        Me.B3_seq_z = New System.Windows.Forms.Button()
        Me.L4_seq_z = New System.Windows.Forms.Label()
        Me.B1_seq_z = New System.Windows.Forms.Button()
        Me.C1_seq_z = New System.Windows.Forms.CheckBox()
        Me.T_fps = New System.Windows.Forms.TextBox()
        Me.T_fadeout = New System.Windows.Forms.TextBox()
        Me.T_fadein = New System.Windows.Forms.TextBox()
        Me.T_activity2 = New System.Windows.Forms.TextBox()
        Me.T_seqf = New System.Windows.Forms.TextBox()
        Me.L8_seq_z = New System.Windows.Forms.Label()
        Me.L7_seq_z = New System.Windows.Forms.Label()
        Me.L6_seq_z = New System.Windows.Forms.Label()
        Me.L5_seq_z = New System.Windows.Forms.Label()
        Me.L3_seq_z = New System.Windows.Forms.Label()
        Me.L1_seq_z = New System.Windows.Forms.Label()
        Me.B4_seq_z = New System.Windows.Forms.Button()
        Me.T_seqp = New System.Windows.Forms.TextBox()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.B_pre_z = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.preview_z = New System.Windows.Forms.TextBox()
        Me.G_Func2_z = New System.Windows.Forms.GroupBox()
        Me.C_cd = New System.Windows.Forms.CheckBox()
        Me.C_seq = New System.Windows.Forms.CheckBox()
        Me.C_mdln = New System.Windows.Forms.CheckBox()
        Me.C_cdm = New System.Windows.Forms.CheckBox()
        Me.C_items = New System.Windows.Forms.CheckBox()
        Me.G_Func_z = New System.Windows.Forms.GroupBox()
        Me.C_ttg = New System.Windows.Forms.CheckBox()
        Me.C_med = New System.Windows.Forms.CheckBox()
        Me.C_jb = New System.Windows.Forms.CheckBox()
        Me.C_bdg = New System.Windows.Forms.CheckBox()
        Me.C_cdl = New System.Windows.Forms.CheckBox()
        Me.B_outpath_z = New System.Windows.Forms.Button()
        Me.B_smdpath_z = New System.Windows.Forms.Button()
        Me.T_outpath_z = New System.Windows.Forms.TextBox()
        Me.T_smdpath_z = New System.Windows.Forms.TextBox()
        Me.L_outpath_z = New System.Windows.Forms.Label()
        Me.L_smdpath_z = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage_other = New System.Windows.Forms.TabPage()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.vmtcreated_b = New System.Windows.Forms.Button()
        Me.samefloders_b = New System.Windows.Forms.Button()
        Me.matflodercreate_b = New System.Windows.Forms.Button()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.en_1 = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Gr_jb_z.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        Me.G_Func2_z.SuspendLayout()
        Me.G_Func_z.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_other.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage_other)
        Me.TabControl1.Controls.Add(Me.TabPage16)
        Me.TabControl1.Location = New System.Drawing.Point(-3, 2)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1205, 586)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.B_preview_s)
        Me.TabPage1.Controls.Add(Me.B_outpath_s)
        Me.TabPage1.Controls.Add(Me.B_smdpath_s)
        Me.TabPage1.Controls.Add(Me.L_preview_s)
        Me.TabPage1.Controls.Add(Me.T_preview_s)
        Me.TabPage1.Controls.Add(Me.T_outpath_s)
        Me.TabPage1.Controls.Add(Me.T_smdpath_s)
        Me.TabPage1.Controls.Add(Me.L_outpath_s)
        Me.TabPage1.Controls.Add(Me.L_smdpath_s)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage1.Size = New System.Drawing.Size(1197, 557)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "简易Qc"
        '
        'B_preview_s
        '
        Me.B_preview_s.Location = New System.Drawing.Point(1049, 485)
        Me.B_preview_s.Margin = New System.Windows.Forms.Padding(4)
        Me.B_preview_s.Name = "B_preview_s"
        Me.B_preview_s.Size = New System.Drawing.Size(131, 34)
        Me.B_preview_s.TabIndex = 14
        Me.B_preview_s.Text = "保存"
        Me.B_preview_s.UseVisualStyleBackColor = True
        '
        'B_outpath_s
        '
        Me.B_outpath_s.Location = New System.Drawing.Point(1049, 128)
        Me.B_outpath_s.Margin = New System.Windows.Forms.Padding(4)
        Me.B_outpath_s.Name = "B_outpath_s"
        Me.B_outpath_s.Size = New System.Drawing.Size(131, 34)
        Me.B_outpath_s.TabIndex = 13
        Me.B_outpath_s.Text = "查找"
        Me.B_outpath_s.UseVisualStyleBackColor = True
        '
        'B_smdpath_s
        '
        Me.B_smdpath_s.Location = New System.Drawing.Point(1049, 58)
        Me.B_smdpath_s.Margin = New System.Windows.Forms.Padding(4)
        Me.B_smdpath_s.Name = "B_smdpath_s"
        Me.B_smdpath_s.Size = New System.Drawing.Size(131, 34)
        Me.B_smdpath_s.TabIndex = 12
        Me.B_smdpath_s.Text = "查找"
        Me.B_smdpath_s.UseVisualStyleBackColor = True
        '
        'L_preview_s
        '
        Me.L_preview_s.AutoSize = True
        Me.L_preview_s.Location = New System.Drawing.Point(25, 174)
        Me.L_preview_s.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_preview_s.Name = "L_preview_s"
        Me.L_preview_s.Size = New System.Drawing.Size(37, 15)
        Me.L_preview_s.TabIndex = 11
        Me.L_preview_s.Text = "预览"
        '
        'T_preview_s
        '
        Me.T_preview_s.Location = New System.Drawing.Point(136, 174)
        Me.T_preview_s.Margin = New System.Windows.Forms.Padding(4)
        Me.T_preview_s.Multiline = True
        Me.T_preview_s.Name = "T_preview_s"
        Me.T_preview_s.Size = New System.Drawing.Size(1043, 303)
        Me.T_preview_s.TabIndex = 10
        '
        'T_outpath_s
        '
        Me.T_outpath_s.Location = New System.Drawing.Point(135, 94)
        Me.T_outpath_s.Margin = New System.Windows.Forms.Padding(4)
        Me.T_outpath_s.Name = "T_outpath_s"
        Me.T_outpath_s.Size = New System.Drawing.Size(1044, 25)
        Me.T_outpath_s.TabIndex = 9
        '
        'T_smdpath_s
        '
        Me.T_smdpath_s.AllowDrop = True
        Me.T_smdpath_s.Location = New System.Drawing.Point(135, 24)
        Me.T_smdpath_s.Margin = New System.Windows.Forms.Padding(4)
        Me.T_smdpath_s.Name = "T_smdpath_s"
        Me.T_smdpath_s.Size = New System.Drawing.Size(1044, 25)
        Me.T_smdpath_s.TabIndex = 8
        '
        'L_outpath_s
        '
        Me.L_outpath_s.AutoSize = True
        Me.L_outpath_s.Location = New System.Drawing.Point(25, 98)
        Me.L_outpath_s.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_outpath_s.Name = "L_outpath_s"
        Me.L_outpath_s.Size = New System.Drawing.Size(67, 15)
        Me.L_outpath_s.TabIndex = 1
        Me.L_outpath_s.Text = "输出路径"
        '
        'L_smdpath_s
        '
        Me.L_smdpath_s.AutoSize = True
        Me.L_smdpath_s.Location = New System.Drawing.Point(25, 28)
        Me.L_smdpath_s.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_smdpath_s.Name = "L_smdpath_s"
        Me.L_smdpath_s.Size = New System.Drawing.Size(93, 15)
        Me.L_smdpath_s.TabIndex = 0
        Me.L_smdpath_s.Text = "smd/dmx路径"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage2.Controls.Add(Me.TabControl2)
        Me.TabPage2.Controls.Add(Me.G_Func2_z)
        Me.TabPage2.Controls.Add(Me.G_Func_z)
        Me.TabPage2.Controls.Add(Me.B_outpath_z)
        Me.TabPage2.Controls.Add(Me.B_smdpath_z)
        Me.TabPage2.Controls.Add(Me.T_outpath_z)
        Me.TabPage2.Controls.Add(Me.T_smdpath_z)
        Me.TabPage2.Controls.Add(Me.L_outpath_z)
        Me.TabPage2.Controls.Add(Me.L_smdpath_z)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage2.Size = New System.Drawing.Size(1197, 557)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "自定义Qc"
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Controls.Add(Me.TabPage8)
        Me.TabControl2.Controls.Add(Me.TabPage9)
        Me.TabControl2.Controls.Add(Me.TabPage10)
        Me.TabControl2.Controls.Add(Me.TabPage11)
        Me.TabControl2.Controls.Add(Me.TabPage12)
        Me.TabControl2.Controls.Add(Me.TabPage13)
        Me.TabControl2.Controls.Add(Me.TabPage14)
        Me.TabControl2.Controls.Add(Me.TabPage15)
        Me.TabControl2.Location = New System.Drawing.Point(15, 224)
        Me.TabControl2.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(1172, 322)
        Me.TabControl2.TabIndex = 27
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage5.Controls.Add(Me.T2_cd_z)
        Me.TabPage5.Controls.Add(Me.T_cd_z)
        Me.TabPage5.Controls.Add(Me.L_cd_z)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage5.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage5.TabIndex = 0
        Me.TabPage5.Text = "$cd"
        '
        'T2_cd_z
        '
        Me.T2_cd_z.Location = New System.Drawing.Point(60, 125)
        Me.T2_cd_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_cd_z.Multiline = True
        Me.T2_cd_z.Name = "T2_cd_z"
        Me.T2_cd_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T2_cd_z.Size = New System.Drawing.Size(999, 68)
        Me.T2_cd_z.TabIndex = 2
        '
        'T_cd_z
        '
        Me.T_cd_z.Location = New System.Drawing.Point(60, 31)
        Me.T_cd_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_cd_z.Name = "T_cd_z"
        Me.T_cd_z.Size = New System.Drawing.Size(999, 25)
        Me.T_cd_z.TabIndex = 1
        '
        'L_cd_z
        '
        Me.L_cd_z.AutoSize = True
        Me.L_cd_z.Location = New System.Drawing.Point(21, 35)
        Me.L_cd_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_cd_z.Name = "L_cd_z"
        Me.L_cd_z.Size = New System.Drawing.Size(31, 15)
        Me.L_cd_z.TabIndex = 0
        Me.L_cd_z.Text = "$cd"
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage6.Controls.Add(Me.B4_mdn_z)
        Me.TabPage6.Controls.Add(Me.B1_mdn_z)
        Me.TabPage6.Controls.Add(Me.B2_mdn_z)
        Me.TabPage6.Controls.Add(Me.B3_mdn_z)
        Me.TabPage6.Controls.Add(Me.T2_mdn_z)
        Me.TabPage6.Controls.Add(Me.T_mdn_z)
        Me.TabPage6.Controls.Add(Me.L_mdn_z)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage6.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage6.TabIndex = 1
        Me.TabPage6.Text = "$modelname"
        '
        'B4_mdn_z
        '
        Me.B4_mdn_z.Location = New System.Drawing.Point(843, 61)
        Me.B4_mdn_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B4_mdn_z.Name = "B4_mdn_z"
        Me.B4_mdn_z.Size = New System.Drawing.Size(132, 36)
        Me.B4_mdn_z.TabIndex = 7
        Me.B4_mdn_z.Text = "使用作者名路径"
        Me.B4_mdn_z.UseVisualStyleBackColor = True
        '
        'B1_mdn_z
        '
        Me.B1_mdn_z.Location = New System.Drawing.Point(983, 209)
        Me.B1_mdn_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B1_mdn_z.Name = "B1_mdn_z"
        Me.B1_mdn_z.Size = New System.Drawing.Size(132, 36)
        Me.B1_mdn_z.TabIndex = 6
        Me.B1_mdn_z.Text = "清空"
        Me.B1_mdn_z.UseVisualStyleBackColor = True
        '
        'B2_mdn_z
        '
        Me.B2_mdn_z.Location = New System.Drawing.Point(704, 61)
        Me.B2_mdn_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B2_mdn_z.Name = "B2_mdn_z"
        Me.B2_mdn_z.Size = New System.Drawing.Size(132, 36)
        Me.B2_mdn_z.TabIndex = 5
        Me.B2_mdn_z.Text = "使用预设"
        Me.B2_mdn_z.UseVisualStyleBackColor = True
        '
        'B3_mdn_z
        '
        Me.B3_mdn_z.Location = New System.Drawing.Point(983, 61)
        Me.B3_mdn_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B3_mdn_z.Name = "B3_mdn_z"
        Me.B3_mdn_z.Size = New System.Drawing.Size(132, 36)
        Me.B3_mdn_z.TabIndex = 4
        Me.B3_mdn_z.Text = "生成(必点)"
        Me.B3_mdn_z.UseVisualStyleBackColor = True
        '
        'T2_mdn_z
        '
        Me.T2_mdn_z.Location = New System.Drawing.Point(115, 132)
        Me.T2_mdn_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_mdn_z.Multiline = True
        Me.T2_mdn_z.Name = "T2_mdn_z"
        Me.T2_mdn_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T2_mdn_z.Size = New System.Drawing.Size(999, 68)
        Me.T2_mdn_z.TabIndex = 3
        '
        'T_mdn_z
        '
        Me.T_mdn_z.Location = New System.Drawing.Point(115, 28)
        Me.T_mdn_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_mdn_z.Name = "T_mdn_z"
        Me.T_mdn_z.Size = New System.Drawing.Size(999, 25)
        Me.T_mdn_z.TabIndex = 2
        '
        'L_mdn_z
        '
        Me.L_mdn_z.AutoSize = True
        Me.L_mdn_z.Location = New System.Drawing.Point(21, 31)
        Me.L_mdn_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_mdn_z.Name = "L_mdn_z"
        Me.L_mdn_z.Size = New System.Drawing.Size(87, 15)
        Me.L_mdn_z.TabIndex = 1
        Me.L_mdn_z.Text = "$modelname"
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage7.Controls.Add(Me.T2_mdl_z)
        Me.TabPage7.Controls.Add(Me.T_mdl_z)
        Me.TabPage7.Controls.Add(Me.L_mdl_z)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage7.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage7.TabIndex = 2
        Me.TabPage7.Text = "$model"
        '
        'T2_mdl_z
        '
        Me.T2_mdl_z.Location = New System.Drawing.Point(101, 132)
        Me.T2_mdl_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_mdl_z.Multiline = True
        Me.T2_mdl_z.Name = "T2_mdl_z"
        Me.T2_mdl_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T2_mdl_z.Size = New System.Drawing.Size(999, 68)
        Me.T2_mdl_z.TabIndex = 3
        '
        'T_mdl_z
        '
        Me.T_mdl_z.Location = New System.Drawing.Point(101, 25)
        Me.T_mdl_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_mdl_z.Name = "T_mdl_z"
        Me.T_mdl_z.Size = New System.Drawing.Size(999, 25)
        Me.T_mdl_z.TabIndex = 2
        '
        'L_mdl_z
        '
        Me.L_mdl_z.AutoSize = True
        Me.L_mdl_z.Location = New System.Drawing.Point(21, 29)
        Me.L_mdl_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_mdl_z.Name = "L_mdl_z"
        Me.L_mdl_z.Size = New System.Drawing.Size(61, 15)
        Me.L_mdl_z.TabIndex = 1
        Me.L_mdl_z.Text = "mdl名字"
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage8.Controls.Add(Me.L2_bdg_z)
        Me.TabPage8.Controls.Add(Me.Name_bdg_z)
        Me.TabPage8.Controls.Add(Me.L_bdg_z)
        Me.TabPage8.Controls.Add(Me.List_bdg_z)
        Me.TabPage8.Controls.Add(Me.B_bdg_z)
        Me.TabPage8.Controls.Add(Me.T_bdg_z)
        Me.TabPage8.Location = New System.Drawing.Point(4, 25)
        Me.TabPage8.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage8.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage8.TabIndex = 3
        Me.TabPage8.Text = "$bodygroups"
        '
        'L2_bdg_z
        '
        Me.L2_bdg_z.AutoSize = True
        Me.L2_bdg_z.Location = New System.Drawing.Point(21, 259)
        Me.L2_bdg_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L2_bdg_z.Name = "L2_bdg_z"
        Me.L2_bdg_z.Size = New System.Drawing.Size(241, 15)
        Me.L2_bdg_z.TabIndex = 7
        Me.L2_bdg_z.Text = "Tip：拖动多个文件到上方自动识别"
        '
        'Name_bdg_z
        '
        Me.Name_bdg_z.Location = New System.Drawing.Point(84, 8)
        Me.Name_bdg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.Name_bdg_z.Name = "Name_bdg_z"
        Me.Name_bdg_z.Size = New System.Drawing.Size(295, 25)
        Me.Name_bdg_z.TabIndex = 6
        Me.Name_bdg_z.Text = "group1"
        '
        'L_bdg_z
        '
        Me.L_bdg_z.AutoSize = True
        Me.L_bdg_z.Location = New System.Drawing.Point(21, 11)
        Me.L_bdg_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_bdg_z.Name = "L_bdg_z"
        Me.L_bdg_z.Size = New System.Drawing.Size(52, 15)
        Me.L_bdg_z.TabIndex = 5
        Me.L_bdg_z.Text = "组名称"
        '
        'List_bdg_z
        '
        Me.List_bdg_z.AllowDrop = True
        Me.List_bdg_z.Location = New System.Drawing.Point(11, 42)
        Me.List_bdg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.List_bdg_z.Multiline = True
        Me.List_bdg_z.Name = "List_bdg_z"
        Me.List_bdg_z.Size = New System.Drawing.Size(487, 196)
        Me.List_bdg_z.TabIndex = 4
        '
        'B_bdg_z
        '
        Me.B_bdg_z.Location = New System.Drawing.Point(365, 251)
        Me.B_bdg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B_bdg_z.Name = "B_bdg_z"
        Me.B_bdg_z.Size = New System.Drawing.Size(135, 31)
        Me.B_bdg_z.TabIndex = 2
        Me.B_bdg_z.Text = "追加/生成"
        Me.B_bdg_z.UseVisualStyleBackColor = True
        '
        'T_bdg_z
        '
        Me.T_bdg_z.Location = New System.Drawing.Point(508, 4)
        Me.T_bdg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_bdg_z.Multiline = True
        Me.T_bdg_z.Name = "T_bdg_z"
        Me.T_bdg_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T_bdg_z.Size = New System.Drawing.Size(640, 278)
        Me.T_bdg_z.TabIndex = 1
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage9.Controls.Add(Me.Label9)
        Me.TabPage9.Controls.Add(Me.L2_jb_z)
        Me.TabPage9.Controls.Add(Me.B3_jb_z)
        Me.TabPage9.Controls.Add(Me.B_jb_z2)
        Me.TabPage9.Controls.Add(Me.GroupBox1)
        Me.TabPage9.Controls.Add(Me.T_jbn_z)
        Me.TabPage9.Controls.Add(Me.L_jb_z)
        Me.TabPage9.Controls.Add(Me.Gr_jb_z)
        Me.TabPage9.Controls.Add(Me.B1_jb_z)
        Me.TabPage9.Controls.Add(Me.T_jb_z)
        Me.TabPage9.Location = New System.Drawing.Point(4, 25)
        Me.TabPage9.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage9.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage9.TabIndex = 4
        Me.TabPage9.Text = "$jigglebone"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(477, 48)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(82, 105)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "函数不想要" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "清空内容" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "即可" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "这里的函数" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "不全以后加" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "手动填区！"
        '
        'L2_jb_z
        '
        Me.L2_jb_z.AutoSize = True
        Me.L2_jb_z.Location = New System.Drawing.Point(519, 11)
        Me.L2_jb_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L2_jb_z.Name = "L2_jb_z"
        Me.L2_jb_z.Size = New System.Drawing.Size(68, 15)
        Me.L2_jb_z.TabIndex = 11
        Me.L2_jb_z.Text = "JB预览："
        '
        'B3_jb_z
        '
        Me.B3_jb_z.Location = New System.Drawing.Point(477, 171)
        Me.B3_jb_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B3_jb_z.Name = "B3_jb_z"
        Me.B3_jb_z.Size = New System.Drawing.Size(112, 30)
        Me.B3_jb_z.TabIndex = 10
        Me.B3_jb_z.Text = "清空预览"
        Me.B3_jb_z.UseVisualStyleBackColor = True
        '
        'B_jb_z2
        '
        Me.B_jb_z2.Location = New System.Drawing.Point(477, 209)
        Me.B_jb_z2.Margin = New System.Windows.Forms.Padding(4)
        Me.B_jb_z2.Name = "B_jb_z2"
        Me.B_jb_z2.Size = New System.Drawing.Size(112, 31)
        Me.B_jb_z2.TabIndex = 9
        Me.B_jb_z2.Text = "恢复默认"
        Me.B_jb_z2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.C1_jb_z)
        Me.GroupBox1.Controls.Add(Me.T_forward_friction)
        Me.GroupBox1.Controls.Add(Me.T_forward_constraint)
        Me.GroupBox1.Controls.Add(Me.T_up_friction)
        Me.GroupBox1.Controls.Add(Me.T_up_constraint)
        Me.GroupBox1.Controls.Add(Me.T_left_friction)
        Me.GroupBox1.Controls.Add(Me.T_left_constraint)
        Me.GroupBox1.Controls.Add(Me.T_damping)
        Me.GroupBox1.Controls.Add(Me.T_stiffness)
        Me.GroupBox1.Controls.Add(Me.T_base_mass)
        Me.GroupBox1.Controls.Add(Me.L_forward_friction)
        Me.GroupBox1.Controls.Add(Me.L_forward_constraint)
        Me.GroupBox1.Controls.Add(Me.L_up_friction)
        Me.GroupBox1.Controls.Add(Me.L_up_constraint)
        Me.GroupBox1.Controls.Add(Me.L_left_friction)
        Me.GroupBox1.Controls.Add(Me.L_left_constraint)
        Me.GroupBox1.Controls.Add(Me.L_damping)
        Me.GroupBox1.Controls.Add(Me.L_stiffness)
        Me.GroupBox1.Controls.Add(Me.L_base_mass)
        Me.GroupBox1.Location = New System.Drawing.Point(240, 30)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(229, 256)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "has_base_spring"
        '
        'C1_jb_z
        '
        Me.C1_jb_z.AutoSize = True
        Me.C1_jb_z.Checked = True
        Me.C1_jb_z.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C1_jb_z.Location = New System.Drawing.Point(128, 0)
        Me.C1_jb_z.Margin = New System.Windows.Forms.Padding(4)
        Me.C1_jb_z.Name = "C1_jb_z"
        Me.C1_jb_z.Size = New System.Drawing.Size(18, 17)
        Me.C1_jb_z.TabIndex = 36
        Me.C1_jb_z.UseVisualStyleBackColor = True
        '
        'T_forward_friction
        '
        Me.T_forward_friction.Location = New System.Drawing.Point(144, 228)
        Me.T_forward_friction.Margin = New System.Windows.Forms.Padding(4)
        Me.T_forward_friction.Name = "T_forward_friction"
        Me.T_forward_friction.Size = New System.Drawing.Size(76, 25)
        Me.T_forward_friction.TabIndex = 35
        Me.T_forward_friction.Text = "0"
        Me.T_forward_friction.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_forward_constraint
        '
        Me.T_forward_constraint.Location = New System.Drawing.Point(144, 201)
        Me.T_forward_constraint.Margin = New System.Windows.Forms.Padding(4)
        Me.T_forward_constraint.Name = "T_forward_constraint"
        Me.T_forward_constraint.Size = New System.Drawing.Size(76, 25)
        Me.T_forward_constraint.TabIndex = 34
        Me.T_forward_constraint.Text = "-0.2 0.2"
        Me.T_forward_constraint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_up_friction
        '
        Me.T_up_friction.Location = New System.Drawing.Point(144, 175)
        Me.T_up_friction.Margin = New System.Windows.Forms.Padding(4)
        Me.T_up_friction.Name = "T_up_friction"
        Me.T_up_friction.Size = New System.Drawing.Size(76, 25)
        Me.T_up_friction.TabIndex = 33
        Me.T_up_friction.Text = "0"
        Me.T_up_friction.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_up_constraint
        '
        Me.T_up_constraint.Location = New System.Drawing.Point(144, 149)
        Me.T_up_constraint.Margin = New System.Windows.Forms.Padding(4)
        Me.T_up_constraint.Name = "T_up_constraint"
        Me.T_up_constraint.Size = New System.Drawing.Size(76, 25)
        Me.T_up_constraint.TabIndex = 32
        Me.T_up_constraint.Text = "-1 1"
        Me.T_up_constraint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_left_friction
        '
        Me.T_left_friction.Location = New System.Drawing.Point(144, 122)
        Me.T_left_friction.Margin = New System.Windows.Forms.Padding(4)
        Me.T_left_friction.Name = "T_left_friction"
        Me.T_left_friction.Size = New System.Drawing.Size(76, 25)
        Me.T_left_friction.TabIndex = 31
        Me.T_left_friction.Text = "0"
        Me.T_left_friction.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_left_constraint
        '
        Me.T_left_constraint.Location = New System.Drawing.Point(144, 96)
        Me.T_left_constraint.Margin = New System.Windows.Forms.Padding(4)
        Me.T_left_constraint.Name = "T_left_constraint"
        Me.T_left_constraint.Size = New System.Drawing.Size(76, 25)
        Me.T_left_constraint.TabIndex = 30
        Me.T_left_constraint.Text = "0 0"
        Me.T_left_constraint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_damping
        '
        Me.T_damping.Location = New System.Drawing.Point(144, 70)
        Me.T_damping.Margin = New System.Windows.Forms.Padding(4)
        Me.T_damping.Name = "T_damping"
        Me.T_damping.Size = New System.Drawing.Size(76, 25)
        Me.T_damping.TabIndex = 29
        Me.T_damping.Text = "5"
        Me.T_damping.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_stiffness
        '
        Me.T_stiffness.Location = New System.Drawing.Point(144, 44)
        Me.T_stiffness.Margin = New System.Windows.Forms.Padding(4)
        Me.T_stiffness.Name = "T_stiffness"
        Me.T_stiffness.Size = New System.Drawing.Size(76, 25)
        Me.T_stiffness.TabIndex = 28
        Me.T_stiffness.Text = "200"
        Me.T_stiffness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_base_mass
        '
        Me.T_base_mass.Location = New System.Drawing.Point(144, 18)
        Me.T_base_mass.Margin = New System.Windows.Forms.Padding(4)
        Me.T_base_mass.Name = "T_base_mass"
        Me.T_base_mass.Size = New System.Drawing.Size(76, 25)
        Me.T_base_mass.TabIndex = 27
        Me.T_base_mass.Text = "60"
        Me.T_base_mass.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'L_forward_friction
        '
        Me.L_forward_friction.AutoSize = True
        Me.L_forward_friction.Location = New System.Drawing.Point(7, 231)
        Me.L_forward_friction.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_forward_friction.Name = "L_forward_friction"
        Me.L_forward_friction.Size = New System.Drawing.Size(135, 15)
        Me.L_forward_friction.TabIndex = 26
        Me.L_forward_friction.Text = "forward_friction"
        '
        'L_forward_constraint
        '
        Me.L_forward_constraint.AutoSize = True
        Me.L_forward_constraint.Location = New System.Drawing.Point(-3, 205)
        Me.L_forward_constraint.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_forward_constraint.Name = "L_forward_constraint"
        Me.L_forward_constraint.Size = New System.Drawing.Size(151, 15)
        Me.L_forward_constraint.TabIndex = 25
        Me.L_forward_constraint.Text = "forward_constraint"
        '
        'L_up_friction
        '
        Me.L_up_friction.AutoSize = True
        Me.L_up_friction.Location = New System.Drawing.Point(7, 179)
        Me.L_up_friction.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_up_friction.Name = "L_up_friction"
        Me.L_up_friction.Size = New System.Drawing.Size(95, 15)
        Me.L_up_friction.TabIndex = 24
        Me.L_up_friction.Text = "up_friction"
        '
        'L_up_constraint
        '
        Me.L_up_constraint.AutoSize = True
        Me.L_up_constraint.Location = New System.Drawing.Point(7, 152)
        Me.L_up_constraint.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_up_constraint.Name = "L_up_constraint"
        Me.L_up_constraint.Size = New System.Drawing.Size(111, 15)
        Me.L_up_constraint.TabIndex = 23
        Me.L_up_constraint.Text = "up_constraint"
        '
        'L_left_friction
        '
        Me.L_left_friction.AutoSize = True
        Me.L_left_friction.Location = New System.Drawing.Point(7, 126)
        Me.L_left_friction.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_left_friction.Name = "L_left_friction"
        Me.L_left_friction.Size = New System.Drawing.Size(111, 15)
        Me.L_left_friction.TabIndex = 22
        Me.L_left_friction.Text = "left_friction"
        '
        'L_left_constraint
        '
        Me.L_left_constraint.AutoSize = True
        Me.L_left_constraint.Location = New System.Drawing.Point(7, 100)
        Me.L_left_constraint.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_left_constraint.Name = "L_left_constraint"
        Me.L_left_constraint.Size = New System.Drawing.Size(127, 15)
        Me.L_left_constraint.TabIndex = 21
        Me.L_left_constraint.Text = "left_constraint"
        '
        'L_damping
        '
        Me.L_damping.AutoSize = True
        Me.L_damping.Location = New System.Drawing.Point(7, 74)
        Me.L_damping.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_damping.Name = "L_damping"
        Me.L_damping.Size = New System.Drawing.Size(63, 15)
        Me.L_damping.TabIndex = 20
        Me.L_damping.Text = "damping"
        '
        'L_stiffness
        '
        Me.L_stiffness.AutoSize = True
        Me.L_stiffness.Location = New System.Drawing.Point(7, 48)
        Me.L_stiffness.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_stiffness.Name = "L_stiffness"
        Me.L_stiffness.Size = New System.Drawing.Size(79, 15)
        Me.L_stiffness.TabIndex = 19
        Me.L_stiffness.Text = "stiffness"
        '
        'L_base_mass
        '
        Me.L_base_mass.AutoSize = True
        Me.L_base_mass.Location = New System.Drawing.Point(7, 21)
        Me.L_base_mass.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_base_mass.Name = "L_base_mass"
        Me.L_base_mass.Size = New System.Drawing.Size(79, 15)
        Me.L_base_mass.TabIndex = 18
        Me.L_base_mass.Text = "base_mass"
        '
        'T_jbn_z
        '
        Me.T_jbn_z.Location = New System.Drawing.Point(84, 0)
        Me.T_jbn_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_jbn_z.Name = "T_jbn_z"
        Me.T_jbn_z.Size = New System.Drawing.Size(384, 25)
        Me.T_jbn_z.TabIndex = 7
        Me.T_jbn_z.Text = "BoneName"
        '
        'L_jb_z
        '
        Me.L_jb_z.AutoSize = True
        Me.L_jb_z.Location = New System.Drawing.Point(21, 8)
        Me.L_jb_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_jb_z.Name = "L_jb_z"
        Me.L_jb_z.Size = New System.Drawing.Size(53, 15)
        Me.L_jb_z.TabIndex = 6
        Me.L_jb_z.Text = "JB名称"
        '
        'Gr_jb_z
        '
        Me.Gr_jb_z.Controls.Add(Me.C2_jb_z)
        Me.Gr_jb_z.Controls.Add(Me.T_angle_constraint)
        Me.Gr_jb_z.Controls.Add(Me.T_along_damping)
        Me.Gr_jb_z.Controls.Add(Me.T_along_stiffness)
        Me.Gr_jb_z.Controls.Add(Me.T_yaw_damping)
        Me.Gr_jb_z.Controls.Add(Me.T_yaw_stiffness)
        Me.Gr_jb_z.Controls.Add(Me.T_pitch_damping)
        Me.Gr_jb_z.Controls.Add(Me.T_pitch_stiffness)
        Me.Gr_jb_z.Controls.Add(Me.T_tip_mass)
        Me.Gr_jb_z.Controls.Add(Me.T_length)
        Me.Gr_jb_z.Controls.Add(Me.L_angle_constraint)
        Me.Gr_jb_z.Controls.Add(Me.L_along_damping)
        Me.Gr_jb_z.Controls.Add(Me.L_along_stiffness)
        Me.Gr_jb_z.Controls.Add(Me.L_yaw_damping)
        Me.Gr_jb_z.Controls.Add(Me.L_yaw_stiffness)
        Me.Gr_jb_z.Controls.Add(Me.L_pitch_damping)
        Me.Gr_jb_z.Controls.Add(Me.L_pitch_stiffness)
        Me.Gr_jb_z.Controls.Add(Me.L_tip_mass)
        Me.Gr_jb_z.Controls.Add(Me.L_length)
        Me.Gr_jb_z.Location = New System.Drawing.Point(15, 26)
        Me.Gr_jb_z.Margin = New System.Windows.Forms.Padding(4)
        Me.Gr_jb_z.Name = "Gr_jb_z"
        Me.Gr_jb_z.Padding = New System.Windows.Forms.Padding(4)
        Me.Gr_jb_z.Size = New System.Drawing.Size(220, 256)
        Me.Gr_jb_z.TabIndex = 3
        Me.Gr_jb_z.TabStop = False
        Me.Gr_jb_z.Text = "is_flexible"
        '
        'C2_jb_z
        '
        Me.C2_jb_z.AutoSize = True
        Me.C2_jb_z.Checked = True
        Me.C2_jb_z.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C2_jb_z.Location = New System.Drawing.Point(100, 0)
        Me.C2_jb_z.Margin = New System.Windows.Forms.Padding(4)
        Me.C2_jb_z.Name = "C2_jb_z"
        Me.C2_jb_z.Size = New System.Drawing.Size(18, 17)
        Me.C2_jb_z.TabIndex = 18
        Me.C2_jb_z.UseVisualStyleBackColor = True
        '
        'T_angle_constraint
        '
        Me.T_angle_constraint.Location = New System.Drawing.Point(140, 228)
        Me.T_angle_constraint.Margin = New System.Windows.Forms.Padding(4)
        Me.T_angle_constraint.Name = "T_angle_constraint"
        Me.T_angle_constraint.Size = New System.Drawing.Size(76, 25)
        Me.T_angle_constraint.TabIndex = 17
        Me.T_angle_constraint.Text = "1"
        Me.T_angle_constraint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_along_damping
        '
        Me.T_along_damping.Location = New System.Drawing.Point(140, 201)
        Me.T_along_damping.Margin = New System.Windows.Forms.Padding(4)
        Me.T_along_damping.Name = "T_along_damping"
        Me.T_along_damping.Size = New System.Drawing.Size(76, 25)
        Me.T_along_damping.TabIndex = 16
        Me.T_along_damping.Text = "0"
        Me.T_along_damping.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_along_stiffness
        '
        Me.T_along_stiffness.Location = New System.Drawing.Point(140, 175)
        Me.T_along_stiffness.Margin = New System.Windows.Forms.Padding(4)
        Me.T_along_stiffness.Name = "T_along_stiffness"
        Me.T_along_stiffness.Size = New System.Drawing.Size(76, 25)
        Me.T_along_stiffness.TabIndex = 15
        Me.T_along_stiffness.Text = "100"
        Me.T_along_stiffness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_yaw_damping
        '
        Me.T_yaw_damping.Location = New System.Drawing.Point(140, 149)
        Me.T_yaw_damping.Margin = New System.Windows.Forms.Padding(4)
        Me.T_yaw_damping.Name = "T_yaw_damping"
        Me.T_yaw_damping.Size = New System.Drawing.Size(76, 25)
        Me.T_yaw_damping.TabIndex = 14
        Me.T_yaw_damping.Text = "4"
        Me.T_yaw_damping.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_yaw_stiffness
        '
        Me.T_yaw_stiffness.Location = New System.Drawing.Point(140, 122)
        Me.T_yaw_stiffness.Margin = New System.Windows.Forms.Padding(4)
        Me.T_yaw_stiffness.Name = "T_yaw_stiffness"
        Me.T_yaw_stiffness.Size = New System.Drawing.Size(76, 25)
        Me.T_yaw_stiffness.TabIndex = 13
        Me.T_yaw_stiffness.Text = "100"
        Me.T_yaw_stiffness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_pitch_damping
        '
        Me.T_pitch_damping.Location = New System.Drawing.Point(140, 96)
        Me.T_pitch_damping.Margin = New System.Windows.Forms.Padding(4)
        Me.T_pitch_damping.Name = "T_pitch_damping"
        Me.T_pitch_damping.Size = New System.Drawing.Size(76, 25)
        Me.T_pitch_damping.TabIndex = 12
        Me.T_pitch_damping.Text = "4"
        Me.T_pitch_damping.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_pitch_stiffness
        '
        Me.T_pitch_stiffness.Location = New System.Drawing.Point(140, 70)
        Me.T_pitch_stiffness.Margin = New System.Windows.Forms.Padding(4)
        Me.T_pitch_stiffness.Name = "T_pitch_stiffness"
        Me.T_pitch_stiffness.Size = New System.Drawing.Size(76, 25)
        Me.T_pitch_stiffness.TabIndex = 11
        Me.T_pitch_stiffness.Text = "100"
        Me.T_pitch_stiffness.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_tip_mass
        '
        Me.T_tip_mass.Location = New System.Drawing.Point(140, 44)
        Me.T_tip_mass.Margin = New System.Windows.Forms.Padding(4)
        Me.T_tip_mass.Name = "T_tip_mass"
        Me.T_tip_mass.Size = New System.Drawing.Size(76, 25)
        Me.T_tip_mass.TabIndex = 10
        Me.T_tip_mass.Text = "5"
        Me.T_tip_mass.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_length
        '
        Me.T_length.Location = New System.Drawing.Point(140, 18)
        Me.T_length.Margin = New System.Windows.Forms.Padding(4)
        Me.T_length.Name = "T_length"
        Me.T_length.Size = New System.Drawing.Size(76, 25)
        Me.T_length.TabIndex = 9
        Me.T_length.Text = "5"
        Me.T_length.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'L_angle_constraint
        '
        Me.L_angle_constraint.AutoSize = True
        Me.L_angle_constraint.Location = New System.Drawing.Point(7, 231)
        Me.L_angle_constraint.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_angle_constraint.Name = "L_angle_constraint"
        Me.L_angle_constraint.Size = New System.Drawing.Size(135, 15)
        Me.L_angle_constraint.TabIndex = 8
        Me.L_angle_constraint.Text = "angle_constraint"
        '
        'L_along_damping
        '
        Me.L_along_damping.AutoSize = True
        Me.L_along_damping.Location = New System.Drawing.Point(7, 205)
        Me.L_along_damping.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_along_damping.Name = "L_along_damping"
        Me.L_along_damping.Size = New System.Drawing.Size(111, 15)
        Me.L_along_damping.TabIndex = 7
        Me.L_along_damping.Text = "along_damping"
        '
        'L_along_stiffness
        '
        Me.L_along_stiffness.AutoSize = True
        Me.L_along_stiffness.Location = New System.Drawing.Point(7, 179)
        Me.L_along_stiffness.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_along_stiffness.Name = "L_along_stiffness"
        Me.L_along_stiffness.Size = New System.Drawing.Size(127, 15)
        Me.L_along_stiffness.TabIndex = 6
        Me.L_along_stiffness.Text = "along_stiffness"
        '
        'L_yaw_damping
        '
        Me.L_yaw_damping.AutoSize = True
        Me.L_yaw_damping.Location = New System.Drawing.Point(7, 152)
        Me.L_yaw_damping.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_yaw_damping.Name = "L_yaw_damping"
        Me.L_yaw_damping.Size = New System.Drawing.Size(95, 15)
        Me.L_yaw_damping.TabIndex = 5
        Me.L_yaw_damping.Text = "yaw_damping"
        '
        'L_yaw_stiffness
        '
        Me.L_yaw_stiffness.AutoSize = True
        Me.L_yaw_stiffness.Location = New System.Drawing.Point(7, 126)
        Me.L_yaw_stiffness.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_yaw_stiffness.Name = "L_yaw_stiffness"
        Me.L_yaw_stiffness.Size = New System.Drawing.Size(111, 15)
        Me.L_yaw_stiffness.TabIndex = 4
        Me.L_yaw_stiffness.Text = "yaw_stiffness"
        '
        'L_pitch_damping
        '
        Me.L_pitch_damping.AutoSize = True
        Me.L_pitch_damping.Location = New System.Drawing.Point(7, 100)
        Me.L_pitch_damping.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_pitch_damping.Name = "L_pitch_damping"
        Me.L_pitch_damping.Size = New System.Drawing.Size(111, 15)
        Me.L_pitch_damping.TabIndex = 3
        Me.L_pitch_damping.Text = "pitch_damping"
        '
        'L_pitch_stiffness
        '
        Me.L_pitch_stiffness.AutoSize = True
        Me.L_pitch_stiffness.Location = New System.Drawing.Point(7, 74)
        Me.L_pitch_stiffness.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_pitch_stiffness.Name = "L_pitch_stiffness"
        Me.L_pitch_stiffness.Size = New System.Drawing.Size(127, 15)
        Me.L_pitch_stiffness.TabIndex = 2
        Me.L_pitch_stiffness.Text = "pitch_stiffness"
        '
        'L_tip_mass
        '
        Me.L_tip_mass.AutoSize = True
        Me.L_tip_mass.Location = New System.Drawing.Point(7, 48)
        Me.L_tip_mass.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_tip_mass.Name = "L_tip_mass"
        Me.L_tip_mass.Size = New System.Drawing.Size(71, 15)
        Me.L_tip_mass.TabIndex = 1
        Me.L_tip_mass.Text = "tip_mass"
        '
        'L_length
        '
        Me.L_length.AutoSize = True
        Me.L_length.Location = New System.Drawing.Point(7, 21)
        Me.L_length.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_length.Name = "L_length"
        Me.L_length.Size = New System.Drawing.Size(55, 15)
        Me.L_length.TabIndex = 0
        Me.L_length.Text = "length"
        '
        'B1_jb_z
        '
        Me.B1_jb_z.Location = New System.Drawing.Point(477, 249)
        Me.B1_jb_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B1_jb_z.Name = "B1_jb_z"
        Me.B1_jb_z.Size = New System.Drawing.Size(112, 31)
        Me.B1_jb_z.TabIndex = 2
        Me.B1_jb_z.Text = "追加"
        Me.B1_jb_z.UseVisualStyleBackColor = True
        '
        'T_jb_z
        '
        Me.T_jb_z.Location = New System.Drawing.Point(597, 8)
        Me.T_jb_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_jb_z.Multiline = True
        Me.T_jb_z.Name = "T_jb_z"
        Me.T_jb_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T_jb_z.Size = New System.Drawing.Size(551, 272)
        Me.T_jb_z.TabIndex = 1
        '
        'TabPage10
        '
        Me.TabPage10.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage10.Controls.Add(Me.Button6)
        Me.TabPage10.Controls.Add(Me.Button5)
        Me.TabPage10.Controls.Add(Me.T_mem_z)
        Me.TabPage10.Controls.Add(Me.Button2)
        Me.TabPage10.Controls.Add(Me.T_Mem)
        Me.TabPage10.Controls.Add(Me.L_Mem)
        Me.TabPage10.Location = New System.Drawing.Point(4, 25)
        Me.TabPage10.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage10.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage10.TabIndex = 5
        Me.TabPage10.Text = "$MaxEyeDeflection"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(660, 44)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(112, 30)
        Me.Button6.TabIndex = 13
        Me.Button6.Text = "清空预览"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(536, 44)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(112, 31)
        Me.Button5.TabIndex = 12
        Me.Button5.Text = "使用"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'T_mem_z
        '
        Me.T_mem_z.Location = New System.Drawing.Point(84, 111)
        Me.T_mem_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_mem_z.Multiline = True
        Me.T_mem_z.Name = "T_mem_z"
        Me.T_mem_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T_mem_z.Size = New System.Drawing.Size(999, 68)
        Me.T_mem_z.TabIndex = 11
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(405, 42)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 31)
        Me.Button2.TabIndex = 10
        Me.Button2.Text = "恢复默认"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'T_Mem
        '
        Me.T_Mem.Location = New System.Drawing.Point(252, 48)
        Me.T_Mem.Margin = New System.Windows.Forms.Padding(4)
        Me.T_Mem.Name = "T_Mem"
        Me.T_Mem.Size = New System.Drawing.Size(93, 25)
        Me.T_Mem.TabIndex = 2
        Me.T_Mem.Text = "90"
        Me.T_Mem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'L_Mem
        '
        Me.L_Mem.AutoSize = True
        Me.L_Mem.Location = New System.Drawing.Point(81, 51)
        Me.L_Mem.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_Mem.Name = "L_Mem"
        Me.L_Mem.Size = New System.Drawing.Size(143, 15)
        Me.L_Mem.TabIndex = 1
        Me.L_Mem.Text = "$MaxEyeDeflection"
        '
        'TabPage11
        '
        Me.TabPage11.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage11.Controls.Add(Me.L_items_z)
        Me.TabPage11.Controls.Add(Me.Button7)
        Me.TabPage11.Controls.Add(Me.Button4)
        Me.TabPage11.Controls.Add(Me.T1_item_z)
        Me.TabPage11.Controls.Add(Me.L1_item_z)
        Me.TabPage11.Location = New System.Drawing.Point(4, 25)
        Me.TabPage11.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage11.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage11.TabIndex = 6
        Me.TabPage11.Text = "杂项"
        '
        'L_items_z
        '
        Me.L_items_z.AutoSize = True
        Me.L_items_z.Location = New System.Drawing.Point(21, 122)
        Me.L_items_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_items_z.Name = "L_items_z"
        Me.L_items_z.Size = New System.Drawing.Size(167, 75)
        Me.L_items_z.TabIndex = 10
        Me.L_items_z.Text = "$surfaceprop ""flesh""" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$contents ""solid""" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$illumposition 0 0 0" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "$mostlyopaque" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.L_items_z.Visible = False
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(552, 39)
        Me.Button7.Margin = New System.Windows.Forms.Padding(4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(124, 39)
        Me.Button7.TabIndex = 9
        Me.Button7.Text = "清空"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(420, 40)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(124, 39)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = "使用预设"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'T1_item_z
        '
        Me.T1_item_z.Location = New System.Drawing.Point(180, 48)
        Me.T1_item_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T1_item_z.Name = "T1_item_z"
        Me.T1_item_z.Size = New System.Drawing.Size(217, 25)
        Me.T1_item_z.TabIndex = 7
        Me.T1_item_z.Text = "username"
        '
        'L1_item_z
        '
        Me.L1_item_z.AutoSize = True
        Me.L1_item_z.Location = New System.Drawing.Point(21, 51)
        Me.L1_item_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L1_item_z.Name = "L1_item_z"
        Me.L1_item_z.Size = New System.Drawing.Size(143, 15)
        Me.L1_item_z.TabIndex = 3
        Me.L1_item_z.Text = "作者名字(用于路径)"
        '
        'TabPage12
        '
        Me.TabPage12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage12.Controls.Add(Me.B4_cdm_z)
        Me.TabPage12.Controls.Add(Me.B3_cdm_z)
        Me.TabPage12.Controls.Add(Me.B2_cdm_z)
        Me.TabPage12.Controls.Add(Me.T1_cdm_z)
        Me.TabPage12.Controls.Add(Me.L1_cdm)
        Me.TabPage12.Controls.Add(Me.B1_cdm_z)
        Me.TabPage12.Controls.Add(Me.T2_cdm_z)
        Me.TabPage12.Location = New System.Drawing.Point(4, 25)
        Me.TabPage12.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage12.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage12.TabIndex = 7
        Me.TabPage12.Text = "$CDMaterials"
        '
        'B4_cdm_z
        '
        Me.B4_cdm_z.Location = New System.Drawing.Point(172, 189)
        Me.B4_cdm_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B4_cdm_z.Name = "B4_cdm_z"
        Me.B4_cdm_z.Size = New System.Drawing.Size(131, 39)
        Me.B4_cdm_z.TabIndex = 7
        Me.B4_cdm_z.Text = "追加/生成(必点)"
        Me.B4_cdm_z.UseVisualStyleBackColor = True
        '
        'B3_cdm_z
        '
        Me.B3_cdm_z.Location = New System.Drawing.Point(179, 142)
        Me.B3_cdm_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B3_cdm_z.Name = "B3_cdm_z"
        Me.B3_cdm_z.Size = New System.Drawing.Size(124, 39)
        Me.B3_cdm_z.TabIndex = 6
        Me.B3_cdm_z.Text = "使用作者路径"
        Me.B3_cdm_z.UseVisualStyleBackColor = True
        '
        'B2_cdm_z
        '
        Me.B2_cdm_z.Location = New System.Drawing.Point(179, 96)
        Me.B2_cdm_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B2_cdm_z.Name = "B2_cdm_z"
        Me.B2_cdm_z.Size = New System.Drawing.Size(124, 39)
        Me.B2_cdm_z.TabIndex = 5
        Me.B2_cdm_z.Text = "使用预设"
        Me.B2_cdm_z.UseVisualStyleBackColor = True
        '
        'T1_cdm_z
        '
        Me.T1_cdm_z.Location = New System.Drawing.Point(13, 50)
        Me.T1_cdm_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T1_cdm_z.Name = "T1_cdm_z"
        Me.T1_cdm_z.Size = New System.Drawing.Size(1135, 25)
        Me.T1_cdm_z.TabIndex = 4
        '
        'L1_cdm
        '
        Me.L1_cdm.AutoSize = True
        Me.L1_cdm.Location = New System.Drawing.Point(17, 20)
        Me.L1_cdm.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L1_cdm.Name = "L1_cdm"
        Me.L1_cdm.Size = New System.Drawing.Size(156, 15)
        Me.L1_cdm.TabIndex = 3
        Me.L1_cdm.Text = "路径 (materials\)："
        '
        'B1_cdm_z
        '
        Me.B1_cdm_z.Location = New System.Drawing.Point(1015, 251)
        Me.B1_cdm_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B1_cdm_z.Name = "B1_cdm_z"
        Me.B1_cdm_z.Size = New System.Drawing.Size(135, 31)
        Me.B1_cdm_z.TabIndex = 2
        Me.B1_cdm_z.Text = "清空"
        Me.B1_cdm_z.UseVisualStyleBackColor = True
        '
        'T2_cdm_z
        '
        Me.T2_cdm_z.Location = New System.Drawing.Point(332, 88)
        Me.T2_cdm_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_cdm_z.Multiline = True
        Me.T2_cdm_z.Name = "T2_cdm_z"
        Me.T2_cdm_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T2_cdm_z.Size = New System.Drawing.Size(816, 155)
        Me.T2_cdm_z.TabIndex = 1
        '
        'TabPage13
        '
        Me.TabPage13.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage13.Controls.Add(Me.Label8)
        Me.TabPage13.Controls.Add(Me.Label7)
        Me.TabPage13.Controls.Add(Me.B1_ttg_z)
        Me.TabPage13.Controls.Add(Me.T1_ttg_z)
        Me.TabPage13.Controls.Add(Me.L1_ttg_z)
        Me.TabPage13.Controls.Add(Me.B2_ttg_z)
        Me.TabPage13.Controls.Add(Me.T2_ttg_z)
        Me.TabPage13.Location = New System.Drawing.Point(4, 25)
        Me.TabPage13.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage13.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage13.TabIndex = 8
        Me.TabPage13.Text = "$TextureGroup"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(444, 20)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 15)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "预览 ："
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 241)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(157, 30)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "每个材质用逗号隔开" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "每个材质组用换行隔开"
        '
        'B1_ttg_z
        '
        Me.B1_ttg_z.Location = New System.Drawing.Point(315, 241)
        Me.B1_ttg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B1_ttg_z.Name = "B1_ttg_z"
        Me.B1_ttg_z.Size = New System.Drawing.Size(124, 39)
        Me.B1_ttg_z.TabIndex = 8
        Me.B1_ttg_z.Text = "生成"
        Me.B1_ttg_z.UseVisualStyleBackColor = True
        '
        'T1_ttg_z
        '
        Me.T1_ttg_z.Location = New System.Drawing.Point(27, 54)
        Me.T1_ttg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T1_ttg_z.Multiline = True
        Me.T1_ttg_z.Name = "T1_ttg_z"
        Me.T1_ttg_z.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.T1_ttg_z.Size = New System.Drawing.Size(411, 179)
        Me.T1_ttg_z.TabIndex = 4
        '
        'L1_ttg_z
        '
        Me.L1_ttg_z.AutoSize = True
        Me.L1_ttg_z.Location = New System.Drawing.Point(24, 20)
        Me.L1_ttg_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L1_ttg_z.Name = "L1_ttg_z"
        Me.L1_ttg_z.Size = New System.Drawing.Size(190, 15)
        Me.L1_ttg_z.TabIndex = 3
        Me.L1_ttg_z.Text = "材质对应数组 ： 最大8*32"
        '
        'B2_ttg_z
        '
        Me.B2_ttg_z.Location = New System.Drawing.Point(1029, 241)
        Me.B2_ttg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B2_ttg_z.Name = "B2_ttg_z"
        Me.B2_ttg_z.Size = New System.Drawing.Size(124, 39)
        Me.B2_ttg_z.TabIndex = 2
        Me.B2_ttg_z.Text = "清空"
        Me.B2_ttg_z.UseVisualStyleBackColor = True
        '
        'T2_ttg_z
        '
        Me.T2_ttg_z.Location = New System.Drawing.Point(447, 54)
        Me.T2_ttg_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T2_ttg_z.Multiline = True
        Me.T2_ttg_z.Name = "T2_ttg_z"
        Me.T2_ttg_z.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.T2_ttg_z.Size = New System.Drawing.Size(705, 179)
        Me.T2_ttg_z.TabIndex = 1
        '
        'TabPage14
        '
        Me.TabPage14.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage14.Controls.Add(Me.L2_seq_z)
        Me.TabPage14.Controls.Add(Me.T_seqn)
        Me.TabPage14.Controls.Add(Me.GroupBox2)
        Me.TabPage14.Controls.Add(Me.L1_seq_z)
        Me.TabPage14.Controls.Add(Me.B4_seq_z)
        Me.TabPage14.Controls.Add(Me.T_seqp)
        Me.TabPage14.Location = New System.Drawing.Point(4, 25)
        Me.TabPage14.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage14.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage14.TabIndex = 9
        Me.TabPage14.Text = "$Sequence"
        '
        'L2_seq_z
        '
        Me.L2_seq_z.AutoSize = True
        Me.L2_seq_z.Location = New System.Drawing.Point(537, 20)
        Me.L2_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L2_seq_z.Name = "L2_seq_z"
        Me.L2_seq_z.Size = New System.Drawing.Size(52, 15)
        Me.L2_seq_z.TabIndex = 17
        Me.L2_seq_z.Text = "预览："
        '
        'T_seqn
        '
        Me.T_seqn.Location = New System.Drawing.Point(133, 9)
        Me.T_seqn.Margin = New System.Windows.Forms.Padding(4)
        Me.T_seqn.Name = "T_seqn"
        Me.T_seqn.Size = New System.Drawing.Size(384, 25)
        Me.T_seqn.TabIndex = 9
        Me.T_seqn.Text = "idle1"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.T_activity1)
        Me.GroupBox2.Controls.Add(Me.B2_seq_z)
        Me.GroupBox2.Controls.Add(Me.B3_seq_z)
        Me.GroupBox2.Controls.Add(Me.L4_seq_z)
        Me.GroupBox2.Controls.Add(Me.B1_seq_z)
        Me.GroupBox2.Controls.Add(Me.C1_seq_z)
        Me.GroupBox2.Controls.Add(Me.T_fps)
        Me.GroupBox2.Controls.Add(Me.T_fadeout)
        Me.GroupBox2.Controls.Add(Me.T_fadein)
        Me.GroupBox2.Controls.Add(Me.T_activity2)
        Me.GroupBox2.Controls.Add(Me.T_seqf)
        Me.GroupBox2.Controls.Add(Me.L8_seq_z)
        Me.GroupBox2.Controls.Add(Me.L7_seq_z)
        Me.GroupBox2.Controls.Add(Me.L6_seq_z)
        Me.GroupBox2.Controls.Add(Me.L5_seq_z)
        Me.GroupBox2.Controls.Add(Me.L3_seq_z)
        Me.GroupBox2.Location = New System.Drawing.Point(25, 42)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(493, 240)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "内容"
        '
        'T_activity1
        '
        Me.T_activity1.Location = New System.Drawing.Point(89, 98)
        Me.T_activity1.Margin = New System.Windows.Forms.Padding(4)
        Me.T_activity1.Name = "T_activity1"
        Me.T_activity1.Size = New System.Drawing.Size(128, 25)
        Me.T_activity1.TabIndex = 19
        Me.T_activity1.Text = """ACT_IDLE"""
        '
        'B2_seq_z
        '
        Me.B2_seq_z.Location = New System.Drawing.Point(229, 140)
        Me.B2_seq_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B2_seq_z.Name = "B2_seq_z"
        Me.B2_seq_z.Size = New System.Drawing.Size(91, 36)
        Me.B2_seq_z.TabIndex = 18
        Me.B2_seq_z.Text = "恢复默认"
        Me.B2_seq_z.UseVisualStyleBackColor = True
        '
        'B3_seq_z
        '
        Me.B3_seq_z.Location = New System.Drawing.Point(343, 192)
        Me.B3_seq_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B3_seq_z.Name = "B3_seq_z"
        Me.B3_seq_z.Size = New System.Drawing.Size(132, 36)
        Me.B3_seq_z.TabIndex = 17
        Me.B3_seq_z.Text = "追加/生成(必点)"
        Me.B3_seq_z.UseVisualStyleBackColor = True
        '
        'L4_seq_z
        '
        Me.L4_seq_z.AutoSize = True
        Me.L4_seq_z.Location = New System.Drawing.Point(56, 61)
        Me.L4_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L4_seq_z.Name = "L4_seq_z"
        Me.L4_seq_z.Size = New System.Drawing.Size(136, 15)
        Me.L4_seq_z.TabIndex = 16
        Me.L4_seq_z.Text = "tip：拖文件到上方"
        '
        'B1_seq_z
        '
        Me.B1_seq_z.Location = New System.Drawing.Point(383, 51)
        Me.B1_seq_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B1_seq_z.Name = "B1_seq_z"
        Me.B1_seq_z.Size = New System.Drawing.Size(91, 36)
        Me.B1_seq_z.TabIndex = 15
        Me.B1_seq_z.Text = "使用预设"
        Me.B1_seq_z.UseVisualStyleBackColor = True
        '
        'C1_seq_z
        '
        Me.C1_seq_z.AutoSize = True
        Me.C1_seq_z.Checked = True
        Me.C1_seq_z.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C1_seq_z.Location = New System.Drawing.Point(9, 209)
        Me.C1_seq_z.Margin = New System.Windows.Forms.Padding(4)
        Me.C1_seq_z.Name = "C1_seq_z"
        Me.C1_seq_z.Size = New System.Drawing.Size(61, 19)
        Me.C1_seq_z.TabIndex = 14
        Me.C1_seq_z.Text = "loop"
        Me.C1_seq_z.UseVisualStyleBackColor = True
        '
        'T_fps
        '
        Me.T_fps.Location = New System.Drawing.Point(141, 176)
        Me.T_fps.Margin = New System.Windows.Forms.Padding(4)
        Me.T_fps.Name = "T_fps"
        Me.T_fps.Size = New System.Drawing.Size(76, 25)
        Me.T_fps.TabIndex = 13
        Me.T_fps.Text = "30"
        Me.T_fps.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_fadeout
        '
        Me.T_fadeout.Location = New System.Drawing.Point(141, 150)
        Me.T_fadeout.Margin = New System.Windows.Forms.Padding(4)
        Me.T_fadeout.Name = "T_fadeout"
        Me.T_fadeout.Size = New System.Drawing.Size(76, 25)
        Me.T_fadeout.TabIndex = 12
        Me.T_fadeout.Text = "0.2"
        Me.T_fadeout.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_fadein
        '
        Me.T_fadein.Location = New System.Drawing.Point(141, 124)
        Me.T_fadein.Margin = New System.Windows.Forms.Padding(4)
        Me.T_fadein.Name = "T_fadein"
        Me.T_fadein.Size = New System.Drawing.Size(76, 25)
        Me.T_fadein.TabIndex = 11
        Me.T_fadein.Text = "0.2"
        Me.T_fadein.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_activity2
        '
        Me.T_activity2.Location = New System.Drawing.Point(229, 98)
        Me.T_activity2.Margin = New System.Windows.Forms.Padding(4)
        Me.T_activity2.Name = "T_activity2"
        Me.T_activity2.Size = New System.Drawing.Size(76, 25)
        Me.T_activity2.TabIndex = 10
        Me.T_activity2.Text = "1"
        Me.T_activity2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'T_seqf
        '
        Me.T_seqf.AllowDrop = True
        Me.T_seqf.Location = New System.Drawing.Point(59, 18)
        Me.T_seqf.Margin = New System.Windows.Forms.Padding(4)
        Me.T_seqf.Name = "T_seqf"
        Me.T_seqf.Size = New System.Drawing.Size(415, 25)
        Me.T_seqf.TabIndex = 9
        Me.T_seqf.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'L8_seq_z
        '
        Me.L8_seq_z.AutoSize = True
        Me.L8_seq_z.Location = New System.Drawing.Point(8, 180)
        Me.L8_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L8_seq_z.Name = "L8_seq_z"
        Me.L8_seq_z.Size = New System.Drawing.Size(31, 15)
        Me.L8_seq_z.TabIndex = 4
        Me.L8_seq_z.Text = "fps"
        '
        'L7_seq_z
        '
        Me.L7_seq_z.AutoSize = True
        Me.L7_seq_z.Location = New System.Drawing.Point(8, 154)
        Me.L7_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L7_seq_z.Name = "L7_seq_z"
        Me.L7_seq_z.Size = New System.Drawing.Size(63, 15)
        Me.L7_seq_z.TabIndex = 3
        Me.L7_seq_z.Text = "fadeout"
        '
        'L6_seq_z
        '
        Me.L6_seq_z.AutoSize = True
        Me.L6_seq_z.Location = New System.Drawing.Point(8, 128)
        Me.L6_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L6_seq_z.Name = "L6_seq_z"
        Me.L6_seq_z.Size = New System.Drawing.Size(55, 15)
        Me.L6_seq_z.TabIndex = 2
        Me.L6_seq_z.Text = "fadein"
        '
        'L5_seq_z
        '
        Me.L5_seq_z.AutoSize = True
        Me.L5_seq_z.Location = New System.Drawing.Point(8, 101)
        Me.L5_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L5_seq_z.Name = "L5_seq_z"
        Me.L5_seq_z.Size = New System.Drawing.Size(71, 15)
        Me.L5_seq_z.TabIndex = 1
        Me.L5_seq_z.Text = "activity"
        '
        'L3_seq_z
        '
        Me.L3_seq_z.AutoSize = True
        Me.L3_seq_z.Location = New System.Drawing.Point(7, 21)
        Me.L3_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L3_seq_z.Name = "L3_seq_z"
        Me.L3_seq_z.Size = New System.Drawing.Size(37, 15)
        Me.L3_seq_z.TabIndex = 0
        Me.L3_seq_z.Text = "文件"
        '
        'L1_seq_z
        '
        Me.L1_seq_z.AutoSize = True
        Me.L1_seq_z.Location = New System.Drawing.Point(23, 12)
        Me.L1_seq_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L1_seq_z.Name = "L1_seq_z"
        Me.L1_seq_z.Size = New System.Drawing.Size(101, 15)
        Me.L1_seq_z.TabIndex = 7
        Me.L1_seq_z.Text = "Sequence标签"
        '
        'B4_seq_z
        '
        Me.B4_seq_z.Location = New System.Drawing.Point(1019, 251)
        Me.B4_seq_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B4_seq_z.Name = "B4_seq_z"
        Me.B4_seq_z.Size = New System.Drawing.Size(135, 31)
        Me.B4_seq_z.TabIndex = 2
        Me.B4_seq_z.Text = "清空"
        Me.B4_seq_z.UseVisualStyleBackColor = True
        '
        'T_seqp
        '
        Me.T_seqp.Location = New System.Drawing.Point(600, 8)
        Me.T_seqp.Margin = New System.Windows.Forms.Padding(4)
        Me.T_seqp.Multiline = True
        Me.T_seqp.Name = "T_seqp"
        Me.T_seqp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.T_seqp.Size = New System.Drawing.Size(552, 235)
        Me.T_seqp.TabIndex = 1
        '
        'TabPage15
        '
        Me.TabPage15.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage15.Controls.Add(Me.Label6)
        Me.TabPage15.Controls.Add(Me.Label10)
        Me.TabPage15.Controls.Add(Me.B_pre_z)
        Me.TabPage15.Controls.Add(Me.Button1)
        Me.TabPage15.Controls.Add(Me.preview_z)
        Me.TabPage15.Location = New System.Drawing.Point(4, 25)
        Me.TabPage15.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage15.Size = New System.Drawing.Size(1164, 293)
        Me.TabPage15.TabIndex = 10
        Me.TabPage15.Text = "预览"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("宋体", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Label6.Location = New System.Drawing.Point(8, 259)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(317, 19)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "***给新smd创建qc时要给函数重定义"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("宋体", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Red
        Me.Label10.Location = New System.Drawing.Point(361, 259)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(476, 19)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "***先确保所有要用到的函数都已经生成，再点最终生成"
        '
        'B_pre_z
        '
        Me.B_pre_z.Location = New System.Drawing.Point(876, 251)
        Me.B_pre_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B_pre_z.Name = "B_pre_z"
        Me.B_pre_z.Size = New System.Drawing.Size(135, 31)
        Me.B_pre_z.TabIndex = 2
        Me.B_pre_z.Text = "最终生成"
        Me.B_pre_z.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1019, 251)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(135, 31)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "保存"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'preview_z
        '
        Me.preview_z.Location = New System.Drawing.Point(8, 8)
        Me.preview_z.Margin = New System.Windows.Forms.Padding(4)
        Me.preview_z.Multiline = True
        Me.preview_z.Name = "preview_z"
        Me.preview_z.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.preview_z.Size = New System.Drawing.Size(1144, 235)
        Me.preview_z.TabIndex = 0
        '
        'G_Func2_z
        '
        Me.G_Func2_z.Controls.Add(Me.C_cd)
        Me.G_Func2_z.Controls.Add(Me.C_seq)
        Me.G_Func2_z.Controls.Add(Me.C_mdln)
        Me.G_Func2_z.Controls.Add(Me.C_cdm)
        Me.G_Func2_z.Controls.Add(Me.C_items)
        Me.G_Func2_z.Location = New System.Drawing.Point(672, 164)
        Me.G_Func2_z.Margin = New System.Windows.Forms.Padding(4)
        Me.G_Func2_z.Name = "G_Func2_z"
        Me.G_Func2_z.Padding = New System.Windows.Forms.Padding(4)
        Me.G_Func2_z.Size = New System.Drawing.Size(508, 49)
        Me.G_Func2_z.TabIndex = 26
        Me.G_Func2_z.TabStop = False
        Me.G_Func2_z.Text = "必备函数"
        '
        'C_cd
        '
        Me.C_cd.AutoSize = True
        Me.C_cd.Checked = True
        Me.C_cd.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C_cd.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.C_cd.Location = New System.Drawing.Point(8, 21)
        Me.C_cd.Margin = New System.Windows.Forms.Padding(4)
        Me.C_cd.Name = "C_cd"
        Me.C_cd.Size = New System.Drawing.Size(53, 19)
        Me.C_cd.TabIndex = 21
        Me.C_cd.Text = "$cd"
        Me.C_cd.UseVisualStyleBackColor = True
        '
        'C_seq
        '
        Me.C_seq.Checked = True
        Me.C_seq.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C_seq.Location = New System.Drawing.Point(400, 21)
        Me.C_seq.Margin = New System.Windows.Forms.Padding(4)
        Me.C_seq.Name = "C_seq"
        Me.C_seq.Size = New System.Drawing.Size(104, 20)
        Me.C_seq.TabIndex = 25
        Me.C_seq.Text = "sequences"
        Me.C_seq.UseVisualStyleBackColor = True
        '
        'C_mdln
        '
        Me.C_mdln.Checked = True
        Me.C_mdln.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C_mdln.Location = New System.Drawing.Point(72, 21)
        Me.C_mdln.Margin = New System.Windows.Forms.Padding(4)
        Me.C_mdln.Name = "C_mdln"
        Me.C_mdln.Size = New System.Drawing.Size(112, 20)
        Me.C_mdln.TabIndex = 22
        Me.C_mdln.Text = "$modelname"
        Me.C_mdln.UseVisualStyleBackColor = True
        '
        'C_cdm
        '
        Me.C_cdm.Checked = True
        Me.C_cdm.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C_cdm.Location = New System.Drawing.Point(264, 21)
        Me.C_cdm.Margin = New System.Windows.Forms.Padding(4)
        Me.C_cdm.Name = "C_cdm"
        Me.C_cdm.Size = New System.Drawing.Size(128, 20)
        Me.C_cdm.TabIndex = 24
        Me.C_cdm.Text = "$cdmaterials"
        Me.C_cdm.UseVisualStyleBackColor = True
        '
        'C_items
        '
        Me.C_items.Checked = True
        Me.C_items.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C_items.Location = New System.Drawing.Point(192, 21)
        Me.C_items.Margin = New System.Windows.Forms.Padding(4)
        Me.C_items.Name = "C_items"
        Me.C_items.Size = New System.Drawing.Size(72, 20)
        Me.C_items.TabIndex = 23
        Me.C_items.Text = "杂项*"
        Me.C_items.UseVisualStyleBackColor = True
        '
        'G_Func_z
        '
        Me.G_Func_z.Controls.Add(Me.C_ttg)
        Me.G_Func_z.Controls.Add(Me.C_med)
        Me.G_Func_z.Controls.Add(Me.C_jb)
        Me.G_Func_z.Controls.Add(Me.C_bdg)
        Me.G_Func_z.Controls.Add(Me.C_cdl)
        Me.G_Func_z.Location = New System.Drawing.Point(8, 164)
        Me.G_Func_z.Margin = New System.Windows.Forms.Padding(4)
        Me.G_Func_z.Name = "G_Func_z"
        Me.G_Func_z.Padding = New System.Windows.Forms.Padding(4)
        Me.G_Func_z.Size = New System.Drawing.Size(660, 49)
        Me.G_Func_z.TabIndex = 20
        Me.G_Func_z.TabStop = False
        Me.G_Func_z.Text = "自定义函数"
        '
        'C_ttg
        '
        Me.C_ttg.AutoSize = True
        Me.C_ttg.Location = New System.Drawing.Point(520, 21)
        Me.C_ttg.Margin = New System.Windows.Forms.Padding(4)
        Me.C_ttg.Name = "C_ttg"
        Me.C_ttg.Size = New System.Drawing.Size(133, 19)
        Me.C_ttg.TabIndex = 4
        Me.C_ttg.Text = "$TextureGroup"
        Me.C_ttg.UseVisualStyleBackColor = True
        '
        'C_med
        '
        Me.C_med.AutoSize = True
        Me.C_med.Location = New System.Drawing.Point(344, 21)
        Me.C_med.Margin = New System.Windows.Forms.Padding(4)
        Me.C_med.Name = "C_med"
        Me.C_med.Size = New System.Drawing.Size(165, 19)
        Me.C_med.TabIndex = 3
        Me.C_med.Text = "$MaxEyeDeflection"
        Me.C_med.UseVisualStyleBackColor = True
        '
        'C_jb
        '
        Me.C_jb.AutoSize = True
        Me.C_jb.Location = New System.Drawing.Point(224, 21)
        Me.C_jb.Margin = New System.Windows.Forms.Padding(4)
        Me.C_jb.Name = "C_jb"
        Me.C_jb.Size = New System.Drawing.Size(117, 19)
        Me.C_jb.TabIndex = 2
        Me.C_jb.Text = "$JiggleBone"
        Me.C_jb.UseVisualStyleBackColor = True
        '
        'C_bdg
        '
        Me.C_bdg.AutoSize = True
        Me.C_bdg.Location = New System.Drawing.Point(96, 21)
        Me.C_bdg.Margin = New System.Windows.Forms.Padding(4)
        Me.C_bdg.Name = "C_bdg"
        Me.C_bdg.Size = New System.Drawing.Size(117, 19)
        Me.C_bdg.TabIndex = 1
        Me.C_bdg.Text = "$bodygroups"
        Me.C_bdg.UseVisualStyleBackColor = True
        '
        'C_cdl
        '
        Me.C_cdl.AutoSize = True
        Me.C_cdl.Checked = True
        Me.C_cdl.CheckState = System.Windows.Forms.CheckState.Checked
        Me.C_cdl.Location = New System.Drawing.Point(8, 21)
        Me.C_cdl.Margin = New System.Windows.Forms.Padding(4)
        Me.C_cdl.Name = "C_cdl"
        Me.C_cdl.Size = New System.Drawing.Size(77, 19)
        Me.C_cdl.TabIndex = 0
        Me.C_cdl.Text = "$model"
        Me.C_cdl.UseVisualStyleBackColor = True
        '
        'B_outpath_z
        '
        Me.B_outpath_z.Location = New System.Drawing.Point(1049, 122)
        Me.B_outpath_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B_outpath_z.Name = "B_outpath_z"
        Me.B_outpath_z.Size = New System.Drawing.Size(131, 34)
        Me.B_outpath_z.TabIndex = 19
        Me.B_outpath_z.Text = "查找"
        Me.B_outpath_z.UseVisualStyleBackColor = True
        '
        'B_smdpath_z
        '
        Me.B_smdpath_z.Location = New System.Drawing.Point(1049, 52)
        Me.B_smdpath_z.Margin = New System.Windows.Forms.Padding(4)
        Me.B_smdpath_z.Name = "B_smdpath_z"
        Me.B_smdpath_z.Size = New System.Drawing.Size(131, 34)
        Me.B_smdpath_z.TabIndex = 18
        Me.B_smdpath_z.Text = "查找"
        Me.B_smdpath_z.UseVisualStyleBackColor = True
        '
        'T_outpath_z
        '
        Me.T_outpath_z.Location = New System.Drawing.Point(135, 89)
        Me.T_outpath_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_outpath_z.Name = "T_outpath_z"
        Me.T_outpath_z.Size = New System.Drawing.Size(1044, 25)
        Me.T_outpath_z.TabIndex = 17
        '
        'T_smdpath_z
        '
        Me.T_smdpath_z.AllowDrop = True
        Me.T_smdpath_z.Location = New System.Drawing.Point(135, 19)
        Me.T_smdpath_z.Margin = New System.Windows.Forms.Padding(4)
        Me.T_smdpath_z.Name = "T_smdpath_z"
        Me.T_smdpath_z.Size = New System.Drawing.Size(1044, 25)
        Me.T_smdpath_z.TabIndex = 16
        '
        'L_outpath_z
        '
        Me.L_outpath_z.AutoSize = True
        Me.L_outpath_z.Location = New System.Drawing.Point(25, 92)
        Me.L_outpath_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_outpath_z.Name = "L_outpath_z"
        Me.L_outpath_z.Size = New System.Drawing.Size(67, 15)
        Me.L_outpath_z.TabIndex = 15
        Me.L_outpath_z.Text = "输出路径"
        '
        'L_smdpath_z
        '
        Me.L_smdpath_z.AutoSize = True
        Me.L_smdpath_z.Location = New System.Drawing.Point(25, 22)
        Me.L_smdpath_z.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.L_smdpath_z.Name = "L_smdpath_z"
        Me.L_smdpath_z.Size = New System.Drawing.Size(93, 15)
        Me.L_smdpath_z.TabIndex = 14
        Me.L_smdpath_z.Text = "smd/dmx路径"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.TextBox5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage3.Size = New System.Drawing.Size(1197, 557)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "帮助"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 21)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(82, 15)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "如何使用："
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.SystemColors.MenuBar
        Me.TextBox5.Enabled = False
        Me.TextBox5.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(16, 55)
        Me.TextBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(1169, 494)
        Me.TextBox5.TabIndex = 2
        Me.TextBox5.TabStop = False
        Me.TextBox5.Text = "1、smd路径栏只需拖拽smd到文本框即可自动适配输出路径栏以及qc名字" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "2、您可以手动修改qc名字和作者名字，作者名字将用于路径" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "3、点击同步可以生" &
    "成自定义区函数" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "4、model 和 bodygroup 均可以拖动文件自动识别" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "5、简易创建不用到函数区，将会自动创建一个最简单的qc" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "6、自" &
    "定义创建将用到函数区打勾的函数" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage4.Controls.Add(Me.Label12)
        Me.TabPage4.Controls.Add(Me.Label11)
        Me.TabPage4.Controls.Add(Me.Label4)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Controls.Add(Me.PictureBox2)
        Me.TabPage4.Controls.Add(Me.PictureBox1)
        Me.TabPage4.Controls.Add(Me.TextBox4)
        Me.TabPage4.Controls.Add(Me.TextBox3)
        Me.TabPage4.Controls.Add(Me.Label2)
        Me.TabPage4.Controls.Add(Me.Label1)
        Me.TabPage4.Controls.Add(Me.TextBox2)
        Me.TabPage4.Controls.Add(Me.TextBox1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(4)
        Me.TabPage4.Size = New System.Drawing.Size(1197, 557)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "日志"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(9, 478)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(166, 15)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "欢迎加入SFM贴吧官方群"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(5, 438)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(212, 15)
        Me.Label11.TabIndex = 15
        Me.Label11.Text = "bug反馈：1174791579@qq.com"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Label4.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label4.Location = New System.Drawing.Point(45, 379)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(129, 20)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "作者 NUA努努"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label3.Location = New System.Drawing.Point(45, 229)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(109, 20)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "QcMaker0.8"
        '
        'PictureBox2
        '
        Me.PictureBox2.ErrorImage = Nothing
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(31, 268)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(172, 96)
        Me.PictureBox2.TabIndex = 12
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(31, 61)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(189, 162)
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.MenuBar
        Me.TextBox4.Enabled = False
        Me.TextBox4.Location = New System.Drawing.Point(664, 48)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(181, 175)
        Me.TextBox4.TabIndex = 10
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.SystemColors.MenuBar
        Me.TextBox3.Enabled = False
        Me.TextBox3.Location = New System.Drawing.Point(447, 48)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(181, 175)
        Me.TextBox3.TabIndex = 9
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(232, 228)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 15)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "日志："
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(232, 29)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 15)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "鸣谢："
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.MenuBar
        Me.TextBox2.Enabled = False
        Me.TextBox2.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.TextBox2.Location = New System.Drawing.Point(235, 48)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(181, 175)
        Me.TextBox2.TabIndex = 6
        Me.TextBox2.Text = "StarCold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Loudomian漏斗面" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "达拉崩吧(Tristan)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "bot" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Mon1K4" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.MenuBar
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.TextBox1.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.TextBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TextBox1.Location = New System.Drawing.Point(235, 246)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox1.Size = New System.Drawing.Size(944, 299)
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.Text = resources.GetString("TextBox1.Text")
        '
        'TabPage_other
        '
        Me.TabPage_other.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage_other.Controls.Add(Me.Button3)
        Me.TabPage_other.Controls.Add(Me.vmtcreated_b)
        Me.TabPage_other.Controls.Add(Me.samefloders_b)
        Me.TabPage_other.Controls.Add(Me.matflodercreate_b)
        Me.TabPage_other.Location = New System.Drawing.Point(4, 25)
        Me.TabPage_other.Name = "TabPage_other"
        Me.TabPage_other.Size = New System.Drawing.Size(1197, 557)
        Me.TabPage_other.TabIndex = 4
        Me.TabPage_other.Text = "其他整合"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(792, 41)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(193, 55)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "高级vmt生成器"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'vmtcreated_b
        '
        Me.vmtcreated_b.Location = New System.Drawing.Point(541, 41)
        Me.vmtcreated_b.Name = "vmtcreated_b"
        Me.vmtcreated_b.Size = New System.Drawing.Size(193, 55)
        Me.vmtcreated_b.TabIndex = 2
        Me.vmtcreated_b.Text = "vmt简易批量生成器"
        Me.vmtcreated_b.UseVisualStyleBackColor = True
        '
        'samefloders_b
        '
        Me.samefloders_b.Location = New System.Drawing.Point(287, 41)
        Me.samefloders_b.Name = "samefloders_b"
        Me.samefloders_b.Size = New System.Drawing.Size(193, 55)
        Me.samefloders_b.TabIndex = 1
        Me.samefloders_b.Text = "同级文件夹批量生成"
        Me.samefloders_b.UseVisualStyleBackColor = True
        '
        'matflodercreate_b
        '
        Me.matflodercreate_b.Location = New System.Drawing.Point(39, 41)
        Me.matflodercreate_b.Name = "matflodercreate_b"
        Me.matflodercreate_b.Size = New System.Drawing.Size(193, 55)
        Me.matflodercreate_b.TabIndex = 0
        Me.matflodercreate_b.Text = "材质文件夹生成器1.0"
        Me.matflodercreate_b.UseVisualStyleBackColor = True
        '
        'TabPage16
        '
        Me.TabPage16.BackColor = System.Drawing.SystemColors.Control
        Me.TabPage16.Controls.Add(Me.en_1)
        Me.TabPage16.Location = New System.Drawing.Point(4, 25)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Size = New System.Drawing.Size(1197, 557)
        Me.TabPage16.TabIndex = 5
        Me.TabPage16.Text = "Translate To English"
        '
        'en_1
        '
        Me.en_1.Location = New System.Drawing.Point(63, 43)
        Me.en_1.Name = "en_1"
        Me.en_1.Size = New System.Drawing.Size(167, 60)
        Me.en_1.TabIndex = 0
        Me.en_1.Text = "translate"
        Me.en_1.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.DefaultExt = "smd"
        Me.OpenFileDialog1.FileName = "C:\default.smd"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1199, 594)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Main"
        Me.Tag = "zh"
        Me.Text = "QcMaker0.8 version2020.4.30"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Gr_jb_z.ResumeLayout(False)
        Me.Gr_jb_z.PerformLayout()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage10.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage11.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage13.PerformLayout()
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage14.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage15.ResumeLayout(False)
        Me.TabPage15.PerformLayout()
        Me.G_Func2_z.ResumeLayout(False)
        Me.G_Func2_z.PerformLayout()
        Me.G_Func_z.ResumeLayout(False)
        Me.G_Func_z.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_other.ResumeLayout(False)
        Me.TabPage16.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents L_preview_s As Label
    Friend WithEvents T_preview_s As TextBox
    Friend WithEvents T_outpath_s As TextBox
    Friend WithEvents T_smdpath_s As TextBox
    Friend WithEvents L_outpath_s As Label
    Friend WithEvents L_smdpath_s As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents B_preview_s As Button
    Friend WithEvents B_outpath_s As Button
    Friend WithEvents B_smdpath_s As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents C_seq As CheckBox
    Friend WithEvents C_cdm As CheckBox
    Friend WithEvents C_items As CheckBox
    Friend WithEvents C_mdln As CheckBox
    Friend WithEvents C_cd As CheckBox
    Friend WithEvents G_Func_z As GroupBox
    Friend WithEvents C_ttg As CheckBox
    Friend WithEvents C_med As CheckBox
    Friend WithEvents C_jb As CheckBox
    Friend WithEvents C_bdg As CheckBox
    Friend WithEvents C_cdl As CheckBox
    Friend WithEvents B_outpath_z As Button
    Friend WithEvents B_smdpath_z As Button
    Friend WithEvents T_outpath_z As TextBox
    Friend WithEvents T_smdpath_z As TextBox
    Friend WithEvents L_outpath_z As Label
    Friend WithEvents L_smdpath_z As Label
    Friend WithEvents G_Func2_z As GroupBox
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents L_cd_z As Label
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents L_mdn_z As Label
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents L_mdl_z As Label
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents L_Mem As Label
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents T_cd_z As TextBox
    Friend WithEvents T_mdn_z As TextBox
    Friend WithEvents T_mdl_z As TextBox
    Friend WithEvents T_Mem As TextBox
    Friend WithEvents B_pre_z As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents preview_z As TextBox
    Friend WithEvents B_bdg_z As Button
    Friend WithEvents T_bdg_z As TextBox
    Friend WithEvents B1_jb_z As Button
    Friend WithEvents T_jb_z As TextBox
    Friend WithEvents B1_cdm_z As Button
    Friend WithEvents T2_cdm_z As TextBox
    Friend WithEvents B2_ttg_z As Button
    Friend WithEvents T2_ttg_z As TextBox
    Friend WithEvents B4_seq_z As Button
    Friend WithEvents T_seqp As TextBox
    Friend WithEvents List_bdg_z As TextBox
    Friend WithEvents Name_bdg_z As TextBox
    Friend WithEvents L_bdg_z As Label
    Friend WithEvents L2_bdg_z As Label
    Friend WithEvents T1_item_z As TextBox
    Friend WithEvents L1_item_z As Label
    Friend WithEvents L_jb_z As Label
    Friend WithEvents Gr_jb_z As GroupBox
    Friend WithEvents B_jb_z2 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents T_jbn_z As TextBox
    Friend WithEvents L_angle_constraint As Label
    Friend WithEvents L_along_damping As Label
    Friend WithEvents L_along_stiffness As Label
    Friend WithEvents L_yaw_damping As Label
    Friend WithEvents L_yaw_stiffness As Label
    Friend WithEvents L_pitch_damping As Label
    Friend WithEvents L_pitch_stiffness As Label
    Friend WithEvents L_tip_mass As Label
    Friend WithEvents L_length As Label
    Friend WithEvents T_forward_friction As TextBox
    Friend WithEvents T_forward_constraint As TextBox
    Friend WithEvents T_up_friction As TextBox
    Friend WithEvents T_up_constraint As TextBox
    Friend WithEvents T_left_friction As TextBox
    Friend WithEvents T_left_constraint As TextBox
    Friend WithEvents T_damping As TextBox
    Friend WithEvents T_stiffness As TextBox
    Friend WithEvents T_base_mass As TextBox
    Friend WithEvents L_forward_friction As Label
    Friend WithEvents L_forward_constraint As Label
    Friend WithEvents L_up_friction As Label
    Friend WithEvents L_up_constraint As Label
    Friend WithEvents L_left_friction As Label
    Friend WithEvents L_left_constraint As Label
    Friend WithEvents L_damping As Label
    Friend WithEvents L_stiffness As Label
    Friend WithEvents L_base_mass As Label
    Friend WithEvents T_angle_constraint As TextBox
    Friend WithEvents T_along_damping As TextBox
    Friend WithEvents T_along_stiffness As TextBox
    Friend WithEvents T_yaw_damping As TextBox
    Friend WithEvents T_yaw_stiffness As TextBox
    Friend WithEvents T_pitch_damping As TextBox
    Friend WithEvents T_pitch_stiffness As TextBox
    Friend WithEvents T_tip_mass As TextBox
    Friend WithEvents T_length As TextBox
    Friend WithEvents B3_jb_z As Button
    Friend WithEvents L2_jb_z As Label
    Friend WithEvents T2_cd_z As TextBox
    Friend WithEvents T2_mdn_z As TextBox
    Friend WithEvents T2_mdl_z As TextBox
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents T_mem_z As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents B1_mdn_z As Button
    Friend WithEvents B2_mdn_z As Button
    Friend WithEvents B3_mdn_z As Button
    Friend WithEvents B4_mdn_z As Button
    Friend WithEvents T1_cdm_z As TextBox
    Friend WithEvents L1_cdm As Label
    Friend WithEvents B4_cdm_z As Button
    Friend WithEvents B3_cdm_z As Button
    Friend WithEvents B2_cdm_z As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents B1_ttg_z As Button
    Friend WithEvents T1_ttg_z As TextBox
    Friend WithEvents L1_ttg_z As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents C1_jb_z As CheckBox
    Friend WithEvents C2_jb_z As CheckBox
    Friend WithEvents T_seqn As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents T_fps As TextBox
    Friend WithEvents T_fadeout As TextBox
    Friend WithEvents T_fadein As TextBox
    Friend WithEvents T_activity2 As TextBox
    Friend WithEvents T_seqf As TextBox
    Friend WithEvents L8_seq_z As Label
    Friend WithEvents L7_seq_z As Label
    Friend WithEvents L6_seq_z As Label
    Friend WithEvents L5_seq_z As Label
    Friend WithEvents L3_seq_z As Label
    Friend WithEvents L1_seq_z As Label
    Friend WithEvents L2_seq_z As Label
    Friend WithEvents L4_seq_z As Label
    Friend WithEvents B1_seq_z As Button
    Friend WithEvents C1_seq_z As CheckBox
    Friend WithEvents T_activity1 As TextBox
    Friend WithEvents B2_seq_z As Button
    Friend WithEvents B3_seq_z As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents L_items_z As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TabPage_other As TabPage
    Friend WithEvents vmtcreated_b As Button
    Friend WithEvents samefloders_b As Button
    Friend WithEvents matflodercreate_b As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents en_1 As Button
End Class
